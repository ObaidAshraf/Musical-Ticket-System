package ch06_gui1;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class FirstFrame3 extends JFrame implements ActionListener {

    ImageIcon ic = new ImageIcon("ctree.gif");
    JButton myButton = new JButton("Press", ic);

    public static void main(String[] args) {
        FirstFrame3 ff = new FirstFrame3();
    }

    public FirstFrame3() {
        setLayout(new FlowLayout());
        setSize(400, 400);
        setTitle("Button");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        add(myButton);
        myButton.addActionListener(this);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        setTitle("Happy Christmas");
    }
}

package ch06_gui1.shapes;

import java.awt.*;

class Circle extends Shape {

   Circle(float x, float y, float size, Color color) {
      super(x, y, size, color);
   }

   public void draw(Graphics g) {
      g.setColor(color);
      g.fillOval((int)x, (int)y, (int)size, (int)size);
      g.setColor(Color.black);
      g.drawOval((int)x, (int)y, (int)size, (int)size);
   }

   public boolean contains(float xx, float yy) {
      float dx = x + size/2 - xx, dy = y + size/2 - yy;
      return dx*dx + dy*dy <= size*size/4;
   }
}
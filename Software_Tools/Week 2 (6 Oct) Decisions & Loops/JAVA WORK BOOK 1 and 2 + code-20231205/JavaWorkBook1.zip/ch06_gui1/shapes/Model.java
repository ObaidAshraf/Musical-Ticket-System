package ch06_gui1.shapes;

import java.awt.*;

class Model {
// Model part of Delegate architecture. 
// Maintains a stack of shapeStack, a chosen shape,
// and an x, y position in a Graphics context

    private ShapeStack shapeStack;    // current collection of shapeStack
    private Shape chosen;         // either null, or top of the stack
    private float x,  y;           // coordinates set by a view

    // static "libraries" of colors and shapeStack
    private static String[] colorNames = {"Black", "White", "Red", "Green", "Yellow",
        "Orange", "Blue", "Magenta", "Pink"};
    private static String[] shapeNames = {"Circle", "Face", "Square", "Window", "Grid"};
    private static Color[] colors = {Color.black, Color.white, Color.red, Color.green,
        Color.yellow, Color.orange, Color.blue, Color.magenta,
        Color.pink};

    private void reSizeShape(float change) {
        if (chosen != null) {
            chosen.changeSize(change);
        }
    }

    // Constructor
    public Model() {
        shapeStack = new ShapeStack();
    }

    public void newShape(int shapeIndex, int colorIndex,
            float x, float y) {
        Color color;
        final float defaultSize = 40.0F; // constant
        this.x = x;
        this.y = y;

        // What's the color?
        color = colors[colorIndex];

        // What's the shape?
        switch (shapeIndex) {
            case 0:
                chosen = new Circle(x, y, defaultSize, color);
                break;
            case 1:
                chosen = new Face(x, y, defaultSize, color);
                break;
            case 2:
                chosen = new Square(x, y, defaultSize, color);
                break;
            case 3:
                chosen = new Window(x, y, defaultSize, color);
                break;
            default:
                chosen = new Grid(x, y, defaultSize, color);
                break;
        }

        shapeStack.push(chosen);
    }

    // Update the view when necessary
    public void drawShapes(Graphics g) {
        shapeStack.draw(g);
    }

    public void selectShape(float x, float y) {
        this.x = x;
        this.y = y;
        chosen = shapeStack.get(x, y);
    // either null, or one of the shapeStack in the stack
    }

    public void moveSelectedShape(float newX, float newY) {
        if (chosen != null) {
            chosen.move(newX - x, newY - y);
            x = newX;
            y = newY;
        }
    }

    public void expandShape() {
        reSizeShape(5.0f);
    }

    public void shrinkShape() {
        reSizeShape(-5.0f);
    }

    public boolean deleteShape() {
        try {
            shapeStack.pop();
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    // get methods, used by a view
    public String[] getColorNames() {
        return colorNames;
    }

    public String[] getShapeNames() {
        return shapeNames;
    }
}
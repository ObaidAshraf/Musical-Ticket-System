package ch06_gui1.shapes;

import java.awt.*;

class Window extends Square {

    Window(float x, float y, float size, Color color) {
        super(x, y, size, color);
    }

    @Override
    public void draw(Graphics g) {
        super.draw(g);
        Color oldColor = g.getColor();
        if (color == Color.black) {
            g.setColor(Color.white);
        } else {
            g.setColor(Color.black);
        }
        g.drawLine((int) (x + size / 2), (int) y,
                (int) (x + size / 2), (int) (y + size));
        g.drawLine((int) x, (int) (y + size / 2),
                (int) (x + size), (int) (y + size / 2));
        g.setColor(oldColor);
    }
}
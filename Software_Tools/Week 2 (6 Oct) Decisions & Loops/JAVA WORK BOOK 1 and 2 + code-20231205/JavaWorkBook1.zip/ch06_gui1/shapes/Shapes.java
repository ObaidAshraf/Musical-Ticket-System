package ch06_gui1.shapes;

// This application allows the user to manipulate
// simple shapes by dragging and resizing them.
// Delegate architecture is used.
import static javax.swing.JOptionPane.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Shapes extends JFrame
        implements ActionListener {
    // use a panel to contain buttons and choice boxes

    private JPanel controls = new JPanel();
    // use a canvas to draw shapes on
    private ShapeCanvas canvas = new ShapeCanvas();
    private JButton delete = new JButton("Delete Shape");
    private JButton larger = new JButton("Larger");
    private JButton smaller = new JButton("Smaller");
    private JComboBox colorChoice = new JComboBox();
    private JComboBox shapeChoice = new JComboBox();
    private Model model; // so the view can see the model

    public static void main(String[] args) {
        Shapes shapes = new Shapes();
        shapes.setTitle("Shape manipulation demo");
        shapes.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        shapes.setVisible(true);
    }

    public Shapes() {
        setLayout(new BorderLayout()); // looks good when resizing
        setSize(670, 550);
        setLocationRelativeTo(null);
        // set background color of canvas to a nice light gray
        canvas.setBackground(new Color(220, 220, 220));

        model = new Model(); // instantiate the model

        // add color names from model to colorChoice
        addItems(model.getColorNames(), colorChoice);

        // add shape names from model to shapeChoice
        addItems(model.getShapeNames(), shapeChoice);

        controls.add(colorChoice);
        controls.add(shapeChoice);
        controls.add(delete);
        delete.addActionListener(this);
        controls.add(larger);
        larger.addActionListener(this);
        controls.add(smaller);
        smaller.addActionListener(this);
        add("South", controls);
        add("Center", canvas);

    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == delete) {
            if (!model.deleteShape()) {
                showMessageDialog(this,
                        "Nothing to delete",
                        "Shapes",
                        INFORMATION_MESSAGE);
            } else {
                canvas.repaint();
            }
        } else if (e.getSource() == larger) {
            model.expandShape();
            canvas.repaint();
        } else if (e.getSource() == smaller) {
            model.shrinkShape();
            canvas.repaint();
        }
    }

    private void addItems(String[] items, JComboBox c) {
        //use a for-each loop (Java v5)
        for (String s : items) {
            c.addItem(s);
        }
    }

    private class ShapeCanvas extends Canvas
            implements MouseListener, MouseMotionListener {

        public ShapeCanvas() {
            addMouseListener(this);
            addMouseMotionListener(this);
        }

        public void paint(Graphics g) {
            model.drawShapes(g);
        }

        public void mouseDragged(MouseEvent e) {
            model.moveSelectedShape(e.getX(), e.getY());
            repaint();
        }

        public void mousePressed(MouseEvent e) {
            // check right mouse button
            if (e.getModifiers() == InputEvent.BUTTON3_MASK) {
                model.newShape(shapeChoice.getSelectedIndex(),
                        colorChoice.getSelectedIndex(),
                        e.getX(), e.getY());
            } else {
                model.selectShape(e.getX(), e.getY());
            }
            repaint();
        }

        public boolean isDoubleBuffered() {
            return true;
        }

        // Empty handlers required by Mouse interfaces
        public void mouseMoved(MouseEvent e) {
        }

        public void mouseClicked(MouseEvent e) {
        }

        public void mouseReleased(MouseEvent e) {
        }

        public void mouseEntered(MouseEvent e) {
        }

        public void mouseExited(MouseEvent e) {
        }
    }
}
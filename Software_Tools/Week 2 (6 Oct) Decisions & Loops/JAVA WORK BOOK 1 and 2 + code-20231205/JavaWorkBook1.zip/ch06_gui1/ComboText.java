package ch06_gui1;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class ComboText extends JFrame implements ActionListener {

    JComboBox tut = new JComboBox();
    JTextArea commentTxt = new JTextArea(2, 15);
    JButton doneBtn = new JButton("Finish");

    public static void main(String[] args) {
        new ComboText();
    }

    public ComboText() {
        setLayout(new BorderLayout());
        setSize(400, 150);
        setTitle("ComboText Demo");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        JPanel top = new JPanel();
        top.setLayout(new FlowLayout());
        tut.addItem("Don");
        tut.addItem("Kate");
        tut.addItem("Bob");
        top.add(new Label("choose your favourite tutor"));
        top.add(tut);
        add("North", top);
        add("Center", commentTxt);
        add("South", doneBtn);
        doneBtn.addActionListener(this);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        String com;
        if (tut.getSelectedItem().equals("Don")) {
            com = " You must like programming";
        } else if (tut.getSelectedItem().equals("Kate")) {
            com = " Flattery will get you nowhere";
        } else {
            com = " You like his pallendromic nature";
        }
        commentTxt.setText(" My conclusion is\n" + com);
    }
}

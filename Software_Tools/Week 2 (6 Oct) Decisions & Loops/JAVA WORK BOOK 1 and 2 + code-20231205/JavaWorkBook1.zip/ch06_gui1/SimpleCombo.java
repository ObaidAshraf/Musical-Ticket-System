package ch06_gui1;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class SimpleCombo extends JFrame implements ActionListener {

    JComboBox colour = new JComboBox();
    JLabel instrLabel = new JLabel("Choose a colour from the drop down menu:  ");
    JTextField colourTxt = new JTextField(15);
    JButton doneBtn = new JButton("Finish");

    public static void main(String[] args) {
        SimpleCombo sc = new SimpleCombo();
    }

    public SimpleCombo() {
        setLayout(new FlowLayout());
        setSize(400, 150);
        setTitle("Colours");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        colour.addItem("red");
        colour.addItem("yellow");
        colour.addItem("blue");
        colour.addItem("green");
        add(instrLabel);
        add(colour);
        add(colourTxt);
        add(doneBtn);
        doneBtn.addActionListener(this);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (colour.getSelectedItem().equals("red")) {
            colourTxt.setText("for poppies");
        } else if (colour.getSelectedItem().equals("yellow")) {
            colourTxt.setText(" like the sun");
        } else if (colour.getSelectedItem().equals("blue")) {
            colourTxt.setText(" like the sky ");
        } else {
            colourTxt.setText(" like the grass");
        }
    }
}

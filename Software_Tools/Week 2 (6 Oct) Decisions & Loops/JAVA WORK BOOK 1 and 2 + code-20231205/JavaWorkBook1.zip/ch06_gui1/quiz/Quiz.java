package ch06_gui1.quiz;

import static javax.swing.JOptionPane.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;

// A bit of a hack, should really use more classes
public class Quiz extends JFrame implements ActionListener {

    JButton run = new JButton("Run Quiz");
    JButton ok = new JButton("OK");
    JTextField txtName = new JTextField(10);
    String name;
    JComboBox numberOfQuestions = new JComboBox();
    JTextField txtQuestion = new JTextField();
    ButtonGroup answerGroup = new ButtonGroup();
    JRadioButton answerButton[] = new JRadioButton[4];
    JRadioButton dummy = new JRadioButton();
    // so all answer buttons can be deselected together
    JTextField txtScore = new JTextField(" 0", 2);
    int nextQuestion;
    int score = 0;

    // questions
    String[] question;
    // four possible answers for each question - 2D array
    String[][] answer;
    // correct answers
    int[] correct;

    public Quiz() {
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(new BorderLayout());
        JPanel top = new JPanel();
        top.setLayout(new FlowLayout());
        for (int i = 1; i <= 10; i++) {
            numberOfQuestions.addItem(i + " ");
        }
        top.add(new JLabel("Name:"));
        top.add(txtName);
        numberOfQuestions.setSelectedItem("5 ");
        top.add(new JLabel("   Number of questions:"));
        top.add(numberOfQuestions);
        top.add(new JLabel("     "));
        top.add(run);
        add("North", top);
        JPanel bottom = new JPanel();
        bottom.setLayout(new FlowLayout());
        bottom.add(ok);
        bottom.add(new JLabel("     Score:"));
        bottom.add(txtScore);
        txtScore.setEditable(false);
        add("South", bottom);
        JPanel middle = new JPanel();
        middle.setLayout(new GridLayout(6, 1));
        middle.add(txtQuestion);
        middle.add(new JLabel("")); // padding
        for (int i = 0; i < 4; i++) {
            answerButton[i] = new JRadioButton();
            middle.add(answerButton[i]);
            answerGroup.add(answerButton[i]);
        }
        dummy = new JRadioButton("", true);
        answerGroup.add(dummy);
        add("Center", middle);
        add("West", new JPanel()); // padding
        add("East", new JPanel()); // padding
        run.addActionListener(this);
        ok.addActionListener(this);
        ok.setVisible(false);
        readQuestions();
    } // end of Quiz constructor

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == run) {
            name = txtName.getText();
            if (name.equals("")) {
                showMessageDialog(this,
                        "Please enter your name first",
                        "Wrong!", JOptionPane.ERROR_MESSAGE);
                return;
            }
            shuffle();
            run.setVisible(false);
            txtName.setEditable(false);
            numberOfQuestions.setEnabled(false);
            ok.setVisible(true);
            nextQuestion = 0;
            score = 0;
            txtScore.setText("" + score);
            set(nextQuestion);
        }

        if (e.getSource() == ok) {
            int nOQ = numberOfQuestions.getSelectedIndex() + 1;
            int corr = correct[nextQuestion];
            if (answerButton[corr].isSelected()) {
                score++;
                txtScore.setText("" + score);
            } else {
                showMessageDialog(this,
                        "The correct answer is " + answer[nextQuestion][corr],
                        "Wrong, " + name + "!", JOptionPane.ERROR_MESSAGE);
            }
            nextQuestion++;
            if (nextQuestion < nOQ) {
                set(nextQuestion);
            } else {
                showMessageDialog(this,
                        score + " out of " + nOQ,
                        name + ", your score is", JOptionPane.INFORMATION_MESSAGE);
                txtQuestion.setText("");
                txtScore.setText("");
                txtName.setText("");
                txtName.setEditable(true);
                numberOfQuestions.setEnabled(true);
                numberOfQuestions.setSelectedIndex(4);
                for (int i = 0; i < 4; i++) {
                    answerButton[i].setText("");
                }
                dummy.setSelected(true);
                run.setVisible(true);
                ok.setVisible(false);
            }
        }
    } // end of actionPerformed

    public static void main(String[] args) {
        Quiz frame = new Quiz();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 250);
        frame.setVisible(true);
    } // end of main method

    private void set(int q) { // set a question
        txtQuestion.setText(question[q]);
        for (int i = 0; i < 4; i++) {
            answerButton[i].setText(answer[q][i]);
        }
        dummy.setSelected(true);
    } // end of set method

    private void shuffle() {
        int j;
        int tempC;
        String tempQ;
        String[] tempA;
        int n = question.length;
        for (int i = 0; i < n; i++) {
            j = (int) (Math.random() * n);
            tempC = correct[i];
            tempQ = question[i];
            tempA = answer[i];
            correct[i] = correct[j];
            question[i] = question[j];
            answer[i] = answer[j];
            correct[j] = tempC;
            question[j] = tempQ;
            answer[j] = tempA;
        }
    } // end of shuffle method

    private void readQuestions() {
        try {
            System.out.println(new File(".").getAbsolutePath());
            BufferedReader in = new BufferedReader(new FileReader("res" + File.separator + "ch06_gui1" + File.separator + "QA.txt"));
            String line = in.readLine();
            int n = Integer.parseInt(line); // 1st line has number of questions
            question = new String[n];
            answer = new String[n][4];
            correct = new int[n];
            String[] part;
            for (int q = 0; q < n; q++) {
                line = in.readLine();
                part = line.split("#");
                question[q] = part[0];
                for (int i = 0; i < 4;) {
                    answer[q][i] = part[++i];
                }
                correct[q] = Integer.parseInt(part[5]);
            }
        } catch (Exception e) {
            System.err.println("Questions file not found or error in input");
            System.exit(1);
        }
    } // end of readQuestions
}
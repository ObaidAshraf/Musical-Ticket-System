package ch06_gui1;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class JFrameBasic
        extends JFrame implements ActionListener {

    public static void main(String[] args) {
        JFrameBasic jf = new JFrameBasic();
    }

    public JFrameBasic() {
        setLayout(new FlowLayout());
        setSize(400, 300);
        setTitle("Title");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        // add your event handling code here
    }
}

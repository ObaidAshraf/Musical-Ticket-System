package ch06_gui1;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class TextAreaDemo extends JFrame implements ActionListener {

    JTextField nameTxt = new JTextField(10);
    JTextArea output = new JTextArea(2, 30);
    JButton sub = new JButton("Submit");

    public static void main(String[] args) {
        TextAreaDemo jf = new TextAreaDemo();
    }

    public TextAreaDemo() {
        setLayout(new FlowLayout());
        setSize(400, 120);
        setTitle("Text Area Demo");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        add(new Label("Type your name:"));
        add(nameTxt);
        add(sub);
        sub.addActionListener(this);
        add(output);
        output.setEditable(false);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        String name = nameTxt.getText();
        String message = "Hello " + name + " \nEnjoy your programming ";
        output.setText(message);
    }
}

package ch06_gui1;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class HelloText extends JFrame implements ActionListener {

    JTextField myText = new JTextField(10);

    public static void main(String[] args) {
        HelloText jt = new HelloText();
    }

    public HelloText() {
        setLayout(new FlowLayout());
        setSize(200, 100);
        setTitle("Text");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        add(myText);
        myText.addActionListener(this);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        myText.setText("Hello");
    }
}

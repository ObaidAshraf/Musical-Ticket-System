package ch06_gui1;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class FirstFrame extends JFrame implements ActionListener {

    public static void main(String[] args) {
        FirstFrame ff = new FirstFrame();
    }

    public FirstFrame() {
        setLayout(new FlowLayout());
        setSize(800, 200);
        setTitle("Portrait");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        // add your event handling code here
    }
}

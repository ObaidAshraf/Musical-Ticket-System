package ch06_gui1.puzzle;

public class Tile extends javax.swing.JButton {
// Unusual, but there's nothing to stop you extending most library classes

    public boolean moved() {
        if (north != null && moved(north)) {
            return true;
        }
        if (south != null && moved(south)) {
            return true;
        }
        if (east != null && moved(east)) {
            return true;
        }
        return (west != null && moved(west));
    }

    // auxiliary overload for moved, does the actual moving
    private boolean moved(Tile t) {
        if (!t.isVisible()) { // found invisible tile, make a move
            t.setText(getText());
            t.setVisible(true);
            setVisible(false);
            return true;
        }
        return false; // no move made
    }

    // Properties to set neighbouring tiles
    public void setNorth(Tile value) {
        north = value;
    }

    public void setSouth(Tile value) {
        south = value;
    }

    public void setEast(Tile value) {
        east = value;
    }

    public void setWest(Tile value) {
        west = value;
    }
    private Tile north,  south,  east,  west; // neighbouring tiles
}
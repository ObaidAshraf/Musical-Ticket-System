package ch06_gui1;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class LabelDemo extends JFrame implements ActionListener {

    JTextField nameTxt = new JTextField(10);
    JButton sub = new JButton("Submit");

    public static void main(String[] args) {
        LabelDemo jf = new LabelDemo();
    }

    public LabelDemo() {
        setLayout(new FlowLayout());
        setSize(400, 100);
        setTitle("Label Demo");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        add(new Label("Type your name:"));
        add(nameTxt);
        add(sub);
        sub.addActionListener(this);
        setVisible(true);
        setResizable(false);
    }

    public void actionPerformed(ActionEvent e) {
        nameTxt.setText("");
    }
}

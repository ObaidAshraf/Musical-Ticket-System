package ch10_arrays;

class Squares {

    public static void main(String[] args) {
        int[] mysquares;
        mysquares = new int[10];
        for (int i = 0; i < 10; i++) {
            mysquares[i] = i * i;
            System.out.println(mysquares[i]);
        }
    }
}


package ch10_arrays;

class  Band
{
	public static void main(String[] args) 
	{
		String band[] = {"John", "Paul", "George", "Ringo"};
		System.out.println(band[3]);
	}
}

package ch10_arrays;

class Order {

    public Order(String drink, double money) {
        String d = drink;
        double m = money;
        if (d.equals("tea")) {
            double change;
            if (money > 70) {
                change = money - 70;
            } else if (money == 70) {
                change = 0;
            } else {
                System.out.println("not enough for tea");
            }
        }
    }
}

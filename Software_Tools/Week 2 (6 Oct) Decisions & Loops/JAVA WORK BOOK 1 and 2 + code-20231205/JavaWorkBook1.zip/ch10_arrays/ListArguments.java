package ch10_arrays;

import static java.lang.System.*;

class ListArguments {

    public static void main(String[] args) {
        out.println("The arguments are:");
        for (int i = 0; i < args.length; i++) {
            out.println(args[i]);
        }
    }
}
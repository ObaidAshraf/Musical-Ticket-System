package ch10_arrays;

class Courses1 {

    public static void main(String[] args) {
        String[] courses;
        courses = new String[4];
        courses[0] = "SB";
        courses[1] = "MP";
        courses[2] = "IBA";
        courses[3] = "MM";
        System.out.println(courses[2]);
    }
}

package ch10_arrays;

class ArrayDemoError {

    public static void main(String[] args) {
        int[] myArray = {1, 4, 9};

        for (int i = 0; i < 4; i++) {
            System.out.println(myArray[i]);
        }

    }
}

package ch10_arrays;

class Statistics {

    public static void main(String[] args) {
        // For this to work, the command line arguments must be well-formed
        // double values.
        // What happens if there are no command line arguments?
        int n = args.length;
        double[] nums = new double[n];
        for (int i = 0; i < n; i++) {
            nums[i] = Double.parseDouble(args[i]);
        }
        System.out.println("Largest is " + max(nums));
        System.out.println("Smallest is " + min(nums));
        System.out.println("Sum is " + sum(nums));
        System.out.println("Mean is " + mean(nums));
        System.out.println("Median is " + median(nums));
        System.out.println("Standard deviation is " + sd(nums));
    }

    private static double max(double[] a) {
        // Double.NEGATIVE_INFINITY is a representation of minus infinity.
        // It is less than any 'actual' double value
        double largest = Double.NEGATIVE_INFINITY;
        for (int i = 0; i < a.length; i++) {
            if (a[i] > largest) {
                largest = a[i];
            }
        }
        return largest;
    }

    private static double min(double[] a) {
        // Double.POSITIVE_INFINITY is a representation of infinity.
        // It is larger than any 'actual' double value
        double smallest = Double.POSITIVE_INFINITY;
        for (int i = 0; i < a.length; i++) {
            if (a[i] < smallest) {
                smallest = a[i];
            }
        }
        return smallest;
    }

    private static double sum(double[] a) {
        double total = 0;
        for (int i = 0; i < a.length; i++) {
            total += a[i];
        }
        return total;
    }

    private static double mean(double[] a) {
        // this returns Double.NaN (Not a Number) if a.length == 0
        // i.e. if there are no command line arguments
        return sum(a) / a.length;
    }

    // the median is the middle number if there are an odd number of numbers
    // or the average of the two middle numbers if there are an even number
    // of numbers, after the array has been sorted
    private static double median(double[] a) {
        java.util.Arrays.sort(a);
        int n = a.length;
        if (n == 0) {
            return Double.NaN;
        } else if (n % 2 == 1) // odd
        {
            return a[n / 2];
        } else {
            return (a[n / 2] + a[n / 2 - 1]) / 2;
        }
    }

    // standard deviation
    private static double sd(double[] a) {
        int n = a.length;
        if (n <= 1) {
            return Double.NaN; // should have at least two numbers to make sense
        }
        double mean = mean(a);
        double total = 0;
        for (int i = 0; i < n; i++) {
            total += (a[i] - mean) * (a[i] - mean);
        }
        return Math.sqrt(total / (n - 1));
    }
}
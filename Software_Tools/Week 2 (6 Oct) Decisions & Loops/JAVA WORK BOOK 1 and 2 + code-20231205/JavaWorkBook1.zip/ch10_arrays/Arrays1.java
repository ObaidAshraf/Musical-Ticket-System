package ch10_arrays;

import static java.lang.System.*;

class Arrays1 {

    public static void main(String[] args) {
        String[] band = {"John", "Paul", "George", "Ringo"};
        out.println("band array:");
        for (int i = 0; i < band.length; i++) {
            out.println(band[i]);
        }

        String s = band[0];
        for (int i = 0; i < band.length - 1; i++) {
            band[i] = band[i + 1];
        }
        band[band.length - 1] = s;

        out.println();
        out.println("new contents of band array:");
        for (int i = 0; i < band.length; i++) {
            out.println(band[i]);
        }
    }
}

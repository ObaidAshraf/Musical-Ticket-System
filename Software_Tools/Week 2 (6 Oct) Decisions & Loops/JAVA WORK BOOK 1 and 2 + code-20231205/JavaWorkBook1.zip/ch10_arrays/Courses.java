package ch10_arrays;

class Courses {

    public static void main(String[] args) {
        String[] courses = {"SB", "MP", "IBA", "MM"};
        System.out.println(courses[3]);
    }
}

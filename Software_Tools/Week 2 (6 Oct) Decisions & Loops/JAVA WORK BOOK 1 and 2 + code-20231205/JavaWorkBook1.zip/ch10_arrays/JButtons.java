package ch10_arrays;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class JButtons extends JFrame implements ActionListener {

    private TextField message = new TextField(13);

    public static void main(String[] args) {
        new JButtons();
    }

    public JButtons() {
        setLayout(new BorderLayout());
        setSize(500, 100);
        JPanel top = new JPanel();
        JButton[] digit = new JButton[10];
        for (int b = 0; b < 10; b++) {
            digit[b] = new JButton("" + b);
            top.add(digit[b]);
            digit[b].addActionListener(this);
        }
        add("North", top);
        JPanel bottom = new JPanel();
        bottom.add(message);
        add("South", bottom);
        setTitle("JButton Array Demo");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        message.setText("Button number is " + e.getActionCommand());
    }
}
package ch10_arrays;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class SimpleButtons extends JFrame
        implements ActionListener {

    public static void main(String[] args) {
        SimpleButtons sb = new SimpleButtons();
    }

    public SimpleButtons() {
        setLayout(new FlowLayout());
        setSize(300, 100);
        setTitle("Title");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JButton[] digit = new JButton[3];
        for (int b = 0; b < 3; b++) {
            digit[b] = new JButton("" + b);
            add(digit[b]);
            digit[b].addActionListener(this);
        }
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (Integer.parseInt(e.getActionCommand()) == 1) {
            setTitle("You are a one off");
        }
    }
}

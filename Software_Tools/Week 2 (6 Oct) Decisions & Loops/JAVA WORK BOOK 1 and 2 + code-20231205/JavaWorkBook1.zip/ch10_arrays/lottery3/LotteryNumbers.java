package ch10_arrays.lottery3;

class LotteryNumbers {

    private int[] numbers;
    private int bonus;

    LotteryNumbers(int size) {
        numbers = new int[size];
        generate();
    }

    public int[] getNumbers() {
        return numbers;
    }

    public int getBonus() {
        return bonus;
    }

    // generate lottery numbers and bonus ball
    // second attempt
    public void generate() {
        // generate random numbers between 1 and 49
        // set up a boolean array to remember the numbers chosen
        // initially all values will be false
        boolean[] chosen = new boolean[50];
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = nextNumber(chosen);
        }
        // generate the bonus ball
        bonus = nextNumber(chosen);
        sort(numbers);
    }

    // returns a random int between 1 and 49
    private int nextNumber(boolean[] chosen) {
        int number;
        do {
            number = (int) (Math.random() * 49) + 1;
        } while (chosen[number]);
        chosen[number] = true;
        return number;
    }

    // sort int array a using bubblesort
    private void sort(int[] a) {
        int t;
        for (int i = a.length - 1; i > 0; i--) {
            for (int j = 0; j < i; j++) {
                if (a[j] > a[j + 1]) {
                    t = a[j];
                    a[j] = a[j + 1];
                    a[j + 1] = t;
                }
            }
        }
    }
}

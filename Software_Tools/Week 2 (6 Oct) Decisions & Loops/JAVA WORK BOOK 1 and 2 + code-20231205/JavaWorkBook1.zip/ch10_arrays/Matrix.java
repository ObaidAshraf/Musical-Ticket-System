package ch10_arrays;

import static java.lang.System.*;

class Matrix {

    public static void main(String[] args) {
        int[][] matrix = new int[5][3];
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 3; j++) {
                matrix[i][j] = 2 * j * i;
            }
        }

        for (int k = 0; k < 5; k++) {
            for (int r = 0; r < 3; r++) {
                out.print("  " + matrix[k][r]);
            }
            out.println();
        }
    }
}

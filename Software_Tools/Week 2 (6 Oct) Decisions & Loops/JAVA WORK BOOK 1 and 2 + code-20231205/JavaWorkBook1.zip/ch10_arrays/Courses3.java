package ch10_arrays;

class Courses3 {

    public static void main(String[] args) {
        String[] courses = {"SB", "MP", "IBA", "MM"};
        for (int i = 0; i < 4; i++) {
            System.out.println(courses[i]);
        }

    }
}

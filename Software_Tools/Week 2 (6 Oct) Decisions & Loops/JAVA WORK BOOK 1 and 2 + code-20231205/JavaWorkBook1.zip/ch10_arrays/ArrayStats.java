package ch10_arrays;

import static java.lang.System.*;

class ArrayStats {

    public static void main(String[] args) {
        double[] argsD = new double[args.length];
        for (int i = 0; i < args.length; i++) {
            argsD[i] = Double.parseDouble(args[i]);
        }
        out.println("Maximum of arguments is " + max(argsD));
        out.println("Minimum of arguments is " + min(argsD));
        out.println("Sum of arguments is " + sum(argsD));
        out.println("Average of arguments is " + average(argsD));
        out.println("Arguments reversed are: ");
        String[] rev = reverse(args);
        for (int i = 0; i < rev.length; i++) {
            // no comma needed for first number
            if (i > 0) {
                out.print(", ");
            }
            out.print(rev[i]);
        }
        out.println();
    }

    public static double max(double[] a) {
        double largest = Double.NEGATIVE_INFINITY;
        for (int i = 0; i < a.length; i++) {
            if (a[i] > largest) {
                largest = a[i];
            }
        }
        return largest;
    }

    public static double min(double[] a) {
        double smallest = Double.POSITIVE_INFINITY;
        for (int i = 0; i < a.length; i++) {
            if (a[i] < smallest) {
                smallest = a[i];
            }
        }
        return smallest;
    }

    public static double sum(double[] a) {
        double answer = 0;
        for (int i = 0; i < a.length; i++) {
            answer += a[i];
        }
        return answer;
    }

    public static double average(double[] a) {
        return sum(a) / a.length;
    }

    public static String[] reverse(String[] a) {
        int len = a.length;
        String[] b = new String[len];
        for (int i = 0; i < len; i++) {
            b[len - i - 1] = a[i];
        }
        return b;
    }
}

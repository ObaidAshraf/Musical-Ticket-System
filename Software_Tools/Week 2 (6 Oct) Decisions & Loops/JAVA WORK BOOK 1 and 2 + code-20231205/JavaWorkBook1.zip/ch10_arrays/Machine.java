package ch10_arrays;

class Machine {

    public static void main(String[] args) {
        Order[] machine = new Order[100];
        Order ord1 = new Order("tea", 70);
    }
}

package ch10_arrays.lottery1;

class LotteryNumbers {

    private int[] numbers;
    private int bonus;

    LotteryNumbers(int size) {
        numbers = new int[size];
        generate();
    }

    public int[] getNumbers() {
        return numbers;
    }

    public int getBonus() {
        return bonus;
    }

    // generate lottery numbers and bonus ball
    // first attempt
    public void generate() {
        // generate random numbers between 1 and 49
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = nextNumber();
        }
        // generate the bonus ball
        bonus = nextNumber();
    }

    // returns a random int between 1 and 49
    private int nextNumber() {
        int number;
        number = (int) (Math.random() * 49) + 1;
        return number;
    }
}
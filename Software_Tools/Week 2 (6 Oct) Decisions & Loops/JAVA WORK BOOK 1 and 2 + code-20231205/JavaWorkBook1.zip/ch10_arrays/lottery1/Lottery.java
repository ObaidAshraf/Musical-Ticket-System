package ch10_arrays.lottery1;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Lottery extends JFrame implements ActionListener {

    private JTextField[] txtNumber = new JTextField[6]; // numbers
    private JTextField txtBonus; // bonus ball
    private JButton select;
    private LotteryNumbers nums;

    public static void main(String[] args) {
        new Lottery();
    }

    Lottery() {
        setLayout(new BorderLayout());
        JPanel top = new JPanel();
        for (int i = 0; i < txtNumber.length; i++) {
            txtNumber[i] = new JTextField(2);
            top.add(txtNumber[i]);
            txtNumber[i].setEditable(false);
        }
        top.add(new JLabel("     Bonus:"));
        txtBonus = new JTextField(2);
        top.add(txtBonus);
        txtBonus.setEditable(false);
        add("North", top);
        JPanel bottom = new JPanel();
        select = new JButton("Select numbers");
        bottom.add(select);
        select.addActionListener(this);
        add("South", bottom);
        setTitle("Lottery numbers");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 100);
        setResizable(false);
        setVisible(true);
        // create a LotteryNumbers object and get
        // the first set of numbers and bonus ball
        nums = new LotteryNumbers(txtNumber.length);
        update(nums.getNumbers(), nums.getBonus());
    }

    // get a new set of numbers and bonus ball
    public void actionPerformed(ActionEvent e) {
        nums.generate();
        update(nums.getNumbers(), nums.getBonus());
    }

    // update the text fields
    private void update(int[] number, int bonus) {
        for (int i = 0; i < number.length; i++) {
            txtNumber[i].setText("" + number[i]);
        }
        txtBonus.setText("" + bonus);
    }
}

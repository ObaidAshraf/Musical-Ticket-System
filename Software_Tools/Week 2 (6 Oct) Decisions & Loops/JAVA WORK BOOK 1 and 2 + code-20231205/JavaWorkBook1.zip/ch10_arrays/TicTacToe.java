package ch10_arrays;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * This application allows you to play TicTacToe (Noughts and Crosses)
 * The board is presented as a 3 by 3 grid of buttons. O and X take
 * turns making a move by clicking a button with no text.
 * The player (O or X) with the first move is chosen at random.
 * After each move the application checks to see if O has won, X has
 * won or the game is a draw. If any of these apply, the result is
 * displayed and the grid buttons are disabled.
 * If none of these apply, the next move is for the other player.
 * Clicking on the reset button returns the game to its initial state.
 */
public class TicTacToe extends JFrame implements ActionListener {

    private JTextField message = new JTextField(7);
    private JButton reset = new JButton("Reset");
    private JButton[][] square = new JButton[3][3];
    private int moves; // number of moves
    private boolean oTurn; // true - O's turn false = X's turn

    public static void main(String[] args) {
        new TicTacToe();
    }

    public TicTacToe() {
        Font f = new Font("Microsoft Sans Serif", Font.BOLD, 40);
        setSize(237, 390); // makes grid buttons 75 X 75
        JPanel top = new JPanel();
        message.setFont(f);
        message.setHorizontalAlignment(JTextField.CENTER);
        top.add(message);
        message.setEditable(false);
        add("North", top);
        JPanel middle = new JPanel();
        middle.setLayout(new GridLayout(3, 3, 2, 2));
        // add the 2d array of game buttons to the grid
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                square[i][j] = new JButton(); // no text
                square[i][j].setFont(f);
                middle.add(square[i][j]);
                square[i][j].addActionListener(this);
            }
        }
        add("Center", middle);
        JPanel bottom = new JPanel();
        reset.setFont(f);
        bottom.add(reset);
        reset.addActionListener(this);
        add("South", bottom);
        setTitle("Tic Tac Toe");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setVisible(true);
        reset();
    } // end of constructor

    private void move() {
        if (checkWin("O")) {
            message.setText("O wins");
            disableSquares();
        } else if (checkWin("X")) {
            message.setText("X wins");
            disableSquares();
        } else if (moves == 9) {
            message.setText("Draw");
            disableSquares();
        } else if (oTurn) {
            message.setText("O's turn");
        } else {
            message.setText("X's turn");
        }
        moves++;
    } // end of move

    public void actionPerformed(ActionEvent e) {
        JButton source = (JButton) e.getSource(); // cast needed
        if (source == reset) {
            reset();
            return;
        }
        // source must be one of the nine game buttons
        if (source.getText().equals("")) { // empty square
            if (oTurn) {
                source.setText("O");
            } else {
                source.setText("X");
            }
            oTurn = !oTurn; // switches between X's turn and O's turn
            move();
        }
    } // end of actionPerformed

    private boolean checkWin(String s) {
        boolean won;
        // check each row
        for (int i = 0; i < 3; i++) {
            won = true; // this may change
            for (int j = 0; j < 3; j++) {
                if (square[i][j].getText() != s) {
                    won = false;
                }
            }
            if (won) {
                return true;
            }
        }
        // then each column
        for (int i = 0; i < 3; i++) {
            won = true; // this may change
            for (int j = 0; j < 3; j++) {
                if (square[j][i].getText() != s) {
                    won = false;
                }
            }
            if (won) {
                return true;
            }
        }
        // then the top left to bottom right diagonal
        won = true;
        for (int i = 0; i < 3; i++) {
            if (square[i][i].getText() != s) {
                won = false;
            }
        }
        if (won) {
            return true;
        }
        // then the bottom left to top right diagonal
        won = true;
        for (int i = 0; i < 3; i++) {
            if (square[i][2 - i].getText() != s) {
                won = false;
            }
        }
        if (won) {
            return true;
        }
        // if we get here there is no win yet
        return false;
    } // end of checkWin

    // disables all the buttons
    private void disableSquares() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                square[i][j].setEnabled(false);
            }
        }
    } // end of disableSquares

    // reset game. Note that in java a method can have the same name as a variable.
    private void reset() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                square[i][j].setText("");
                square[i][j].setEnabled(true);
            }
        }
        oTurn = Math.random() < 0.5; // select O or X first at random
        moves = 0;
        move();
    } // end of reset
} // end of TicTacToe application
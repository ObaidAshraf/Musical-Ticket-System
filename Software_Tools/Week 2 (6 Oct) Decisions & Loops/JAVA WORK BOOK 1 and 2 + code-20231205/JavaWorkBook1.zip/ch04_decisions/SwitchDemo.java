package ch04_decisions;

import static javax.swing.JOptionPane.*;

class SwitchDemo {

    public static void main(String[] args) {
        String numStr = showInputDialog("Please type a whole number");
        int dayNum = Integer.parseInt(numStr);
        String dayName;
        switch (dayNum) {
            case 0:
                dayName = "Sunday";
                break;
            case 1:
                dayName = "Monday";
                break;
            case 2:
                dayName = "Tuesday";
                break;
            case 3:
                dayName = "Wednesday";
                break;
            case 4:
                dayName = "Thursday";
                break;
            case 5:
                dayName = "Friday";
                break;
            case 6:
                dayName = "Saturday";
                break;
            default:
                dayName = "Not a day";
        }
        showMessageDialog(null, dayName);
    }
}

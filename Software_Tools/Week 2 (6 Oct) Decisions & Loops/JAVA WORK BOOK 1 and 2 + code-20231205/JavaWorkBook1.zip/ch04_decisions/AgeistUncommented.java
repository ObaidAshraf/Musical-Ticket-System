package ch04_decisions;

import static javax.swing.JOptionPane.*;

class AgeistUncommented {

    public static void main(String[] args) {
        String ageStr = showInputDialog("Please type your age");
        int age = Integer.parseInt(ageStr);
        if (age >= 21) {
            showMessageDialog(null, "Hello wrinkly");
        }
    }
}


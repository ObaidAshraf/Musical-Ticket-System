package ch04_decisions;

import static javax.swing.JOptionPane.*;

class HelloAge3 {

    public static void main(String[] args) {
        String name = showInputDialog("Please type your name");
        String ageStr = showInputDialog("Please type your age");
        int age = Integer.parseInt(ageStr);

        int sex = showConfirmDialog(null, "Are you male?");

        String title;
        if (sex == 0) {
            if (age >= 18) {
                title = "Mr. ";
            } else {
                title = "Master ";
            }
        } else {
            if (age >= 18) {
                title = "Ms. ";
            } else {
                title = "Miss ";
            }
        }

        String freedom;
        if (age >= 60) {
            freedom = "\nYou are entitled to a freedom pass";
        } else {
            freedom = "\nYou are not entitled to a freedom pass";
        }

        showMessageDialog(null,
                "Hello " + age + " year old " + title + name + freedom);
    }
}
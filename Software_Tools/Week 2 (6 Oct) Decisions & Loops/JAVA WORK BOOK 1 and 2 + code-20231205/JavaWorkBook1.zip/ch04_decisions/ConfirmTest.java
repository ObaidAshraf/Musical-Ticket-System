package ch04_decisions;

import static javax.swing.JOptionPane.*;
import static java.lang.System.*;

class ConfirmTest {

    public static void main(String[] args) {

        int value1 = showConfirmDialog(null, "press the Yes");
        out.println("Value returned is" + value1);
        int value2 = showConfirmDialog(null, "press the No");
        out.println("Value returned is" + value2);
        int value3 = showConfirmDialog(null, "press the Cancel");
        out.println("Value returned is" + value3);
    }
}

package ch04_decisions;

import static javax.swing.JOptionPane.*;

class SquareRoot {

    public static void main(String[] args) {
        String xStr = showInputDialog("Please type the value of x");
        double x = Double.parseDouble(xStr);
        if (x < 0);
        {
            showMessageDialog(null, "Error: x is negative");
            x = -x;
        }
        // x is non-negative so we can find and display its square root
        showMessageDialog(null, "The square root of " +
                x + " is " + Math.sqrt(x));
    }
}

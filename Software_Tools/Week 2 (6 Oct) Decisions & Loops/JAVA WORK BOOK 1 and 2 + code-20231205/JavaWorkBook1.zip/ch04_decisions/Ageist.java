package ch04_decisions;

//the java library classes that allow us to use JOptionPane
import static javax.swing.JOptionPane.*;

class Ageist {

    public static void main(String[] args) {//states that the method main can take in an array of arguments
        /*declares ageStr as type String and says we will find
        its value in the Input Dialog which has the text
        'Please type your age' displayed*/
        String ageStr = showInputDialog("Please type your age");
        //chages the String ageStr into the integer value for age
        int age = Integer.parseInt(ageStr);
        /* selection statement set up so that if age >21 then the message
        'Hello wrinkly' is put out otherwise nothing happens */
        if (age >= 21) {
            showMessageDialog(null, "Hello wrinkly");
        }
    }
}


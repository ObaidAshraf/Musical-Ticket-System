package ch04_decisions;

import static javax.swing.JOptionPane.*;

class HelloAge {

    public static void main(String[] args) {
        String name = showInputDialog("Please type your name");
        String ageStr = showInputDialog("Please type your age");
        int age = Integer.parseInt(ageStr);

        String freedom = "";
        if (age >= 60) {
            freedom = "\nYou are entitled to a freedom pass";
        }
        showMessageDialog(null,
                "Hello " + age + " year old " + name + freedom);
    }
}

package ch04_decisions;

import static javax.swing.JOptionPane.*;

class DaySelector {

    public static void main(String[] args) {
        String numStr =
                showInputDialog("Please type a whole number");
        int dayNum = Integer.parseInt(numStr);
        if (dayNum < 0 || dayNum > 7) {
            dayNum = 7;
        }

        String dayName[] = {"Sunday", "Monday", "Tuesday", "Wednesday",
            "Thursday", "Friday", "Saturday", "Not a day"};

        showMessageDialog(null, dayName[dayNum]);
    }
}

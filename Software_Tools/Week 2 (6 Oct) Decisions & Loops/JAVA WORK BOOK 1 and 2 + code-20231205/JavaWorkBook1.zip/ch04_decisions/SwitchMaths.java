package ch04_decisions;

import static javax.swing.JOptionPane.*;

class SwitchMaths {

    public static void main(String[] args) {
        String gradeStr = showInputDialog("Enter your grade for Maths GCSE");
        char grade = gradeStr.charAt(0);

        String opinion;
        switch (grade) {
            case 'a':
            case 'A':
                opinion = "What a boffin";
                break;
            case 'b':
            case 'B':
                opinion = "That's good";
                break;
            case 'c':
            case 'C':
                opinion = "At least you passed";
                break;
            case 'd':
            case 'D':
                opinion = "A near miss";
                break;
            case 'e':
            case 'E':
                opinion = "A little work to do in that area";
                break;

            default:
                opinion = "Perhaps you are good at English";
        }

        showMessageDialog(null, " You got that?   " + opinion);
    }
}

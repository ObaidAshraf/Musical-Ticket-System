package ch04_decisions;

import static javax.swing.JOptionPane.*;

class HelloAge4 {

    public static void main(String[] args) {
        String name = showInputDialog("Please type your name");
        String ageStr = showInputDialog("Please type your age");
        int age = Integer.parseInt(ageStr);
        int sex = showConfirmDialog(null, "Are you male?");

        String title;
        if (sex == 0 && age >= 18) {
            title = "Mr. ";
        } else if (sex == 0 && age < 18) {
            title = "Master ";
        } else if (sex != 0 && age >= 18) {
            title = "Ms. ";
        } else {
            title = "Miss ";
        }

        String freedom;
        if (age >= 60) {
            freedom = "\nYou are entitled to a freedom pass";
        } else if (age <= 25) {
            freedom = "\nYou are entitled to a young person's railcard";
        } else {
            freedom = "\nYou are not entitled to any pass";
        }

        showMessageDialog(null,
                "Hello " + age + " year old " + title + name + freedom);
    }
}

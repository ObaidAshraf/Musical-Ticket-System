package ch04_decisions;

import static javax.swing.JOptionPane.*;

class Ageist3 {

    public static void main(String[] args) {
        int age = showConfirmDialog(null, "Are you over 21?");

        /* selection statement set up so that if age >21 then the message
        'Hello wrinkly' is put out */
        if (age == 0) {
            showMessageDialog(null, "Hello wrinkly");
        } /* selection statement set up so that if age < 21 then the message
        'You know nothing' is put out */ else {
            showMessageDialog(null, "You know nothing!");
        }
    }
}

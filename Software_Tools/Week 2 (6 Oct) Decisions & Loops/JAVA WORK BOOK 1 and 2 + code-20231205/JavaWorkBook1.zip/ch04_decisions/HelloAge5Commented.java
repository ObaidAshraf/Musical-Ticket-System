package ch04_decisions;

import static javax.swing.JOptionPane.*;

class HelloAge5Commented {

    public static void main(String[] args) {
        String name = showInputDialog("Please type your name");

        String ageStr = showInputDialog("Please type your age");
        int age = Integer.parseInt(ageStr);
        //now have inputs name as a String and age as an int
        int sex = showConfirmDialog(null, "Are you male?");
        // sex now has value 0 1 or 2 depending on the button pressed
        //here we give adult and male values true or false
        //depending on the values of the ints age and sex
        String title;
        boolean adult = (age >= 18);
        //this is equivalent to saying adult has
        //the same truth value as the answer to is age>=18?
        boolean male = (sex == 0);
        //this is equivqlent to saying  male has
        //the same truth value as the answer to is sex ==0 ?
        //( ie the user pressed yes to Are you male?
        if (male && adult) {
            title = "Mr. "; //both male and adult
        } else if (male && !adult) {
            title = "Master "; //male and not adult
        } else if (!male && adult) {
            title = "Ms. ";//not male but adult
        } else {
            title = "Miss ";//anything else
        }
        String freedom;
        if (age >= 60) {
            freedom = "\nYou are entitled to a freedom pass";
        } else if (age <= 25) {
            freedom = "\nYou are entitled to a young person's railcard";
        } else {
            freedom = "\nYou are not entitled to any pass";
        }

        showMessageDialog(null, "Hello " + age + " year old " + title + name + freedom);
    }
}

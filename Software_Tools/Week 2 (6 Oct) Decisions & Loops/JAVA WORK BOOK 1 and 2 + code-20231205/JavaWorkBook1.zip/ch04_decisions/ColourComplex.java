package ch04_decisions;

import javax.swing.JOptionPane;
import static java.lang.System.*;

class ColourComplex {

    public static void main(String[] args) {
        String sex = JOptionPane.showInputDialog("boy or girl?");
        if (sex.equals("boy")) {
            out.println("you must wear blue");
            out.println("it is traditional !");
        }
    }
}

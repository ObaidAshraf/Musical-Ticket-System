package ch08_auxiliaryclasses.taxcalculator;

class TaxCalc {
    // instance variables

    private double taxable;
    private double tax;

    // constructor, which does the tax calculation
    TaxCalc(double gross, int nKids, boolean married) {
        // calculate taxable income first
        // this is gross - personal allowance - child allowance

        // calculate personal allowance
        double personalAllowance, childAllowance;
        if (married) {
            personalAllowance = 3000;
        } else {
            personalAllowance = 2000;
        }

        // calculate child allowance
        childAllowance = nKids * 500;

        // calculate taxable. If negative, set it to zero
        taxable = gross - personalAllowance - childAllowance;
        if (taxable < 0) {
            taxable = 0;
        }

        // calculate tax. There are three bands:
        //		taxable <= 20,000
        //		tax is 20% of taxable
        //		20,000 < taxable <= 40,000
        //		tax is 20% of first 20,000 +
        //			   40% of remainder
        //		taxable > 40,000
        //		tax is 20% of first 20,000 +
        //			   40% of next 20,000 +
        //			   60% of remainder
        double remainder;
        if (taxable <= 20000) {
            // first band
            tax = 0.2 * taxable;
        } else if (taxable <= 40000) {
            // second band
            remainder = taxable - 20000;
            tax = 4000 + 0.4 * remainder;
        } else {
            remainder = taxable - 40000;
            tax = 4000 + 8000 + 0.6 * remainder;
        }
    } //  end of constructor

    // get methods to return taxable and tax which
    // have been calculated by the constructor
    public double getTaxable() {
        return taxable;
    }

    public double getTax() {
        return tax;
    }
}
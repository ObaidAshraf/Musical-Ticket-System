package ch08_auxiliaryclasses.taxcalculator;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.text.DecimalFormat;

public class TaxCalcApp extends JFrame
        implements ActionListener {

    DecimalFormat doshky = new DecimalFormat("#,##0.00 dk");
    JButton calculate = new JButton("Calculate Tax");
    JTextField grossTxt = new JTextField(7);

    // allow for 50 kids!
    JSpinner nKidsSp = new JSpinner(new SpinnerNumberModel(0, 0, 50, 1));
    JTextField taxableTxt = new JTextField(11);
    JTextField taxTxt = new JTextField(11);
    JRadioButton married = new JRadioButton("Married", true);
    JRadioButton single = new JRadioButton("Single", false);
    ButtonGroup bg = new ButtonGroup();

    public static void main(String[] args) {
        new TaxCalcApp();
    }

    public TaxCalcApp() {
        setLayout(new BorderLayout());
        setSize(500, 135);
        setTitle("Income Tax Calculator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel top = new JPanel();
        top.add(new JLabel("Gross salary:"));
        top.add(grossTxt);
        bg.add(married);
        bg.add(single);
        top.add(married);
        top.add(single);
        top.add(new JLabel("Number of children:"));
        top.add(nKidsSp);
        add("North", top);

        JPanel middle = new JPanel();
        taxableTxt.setEditable(false);
        taxTxt.setEditable(false);
        middle.add(new JLabel("Taxable income:"));
        middle.add(taxableTxt);
        middle.add(new JLabel("   Tax:"));
        middle.add(taxTxt);
        add("Center", middle);

        JPanel bottom = new JPanel();
        bottom.add(calculate);
        calculate.addActionListener(this);
        add("South", bottom);

        setResizable(false);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        // get input and use auxiliary class to do tax calculations
        int gross, nKids;
        boolean isMarried;
        try {
            gross = Integer.parseInt(grossTxt.getText());
            nKids = Integer.parseInt("" + nKidsSp.getValue());
            isMarried = married.isSelected();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Bad input, try again");
            grossTxt.setText(""); // wipe out offending input
            return; // return from actionPerformed
        }

        TaxCalc tc = new TaxCalc(gross, nKids, isMarried);
        taxableTxt.setText(doshky.format(tc.getTaxable()));
        taxTxt.setText(doshky.format(tc.getTax()));
    }
}
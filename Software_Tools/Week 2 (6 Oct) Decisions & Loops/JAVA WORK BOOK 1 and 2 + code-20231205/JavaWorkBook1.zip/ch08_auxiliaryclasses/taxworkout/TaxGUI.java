package ch08_auxiliaryclasses.taxworkout;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.text.DecimalFormat;
//Kates version
public class TaxGUI extends JFrame
        implements ActionListener {

    JLabel payLabel = new JLabel("Enter you gross annual pay:  ");
    JTextField payTxt = new JTextField(10);
    JRadioButton marriedRB = new JRadioButton("click here if married", false);
    JRadioButton singleRB = new JRadioButton("click here if not married", true);
    ButtonGroup status = new ButtonGroup();
    JLabel numKidsLabel = new JLabel("Enter the number of children you have:  ");
    JTextField numKidsTxt = new JTextField(10);
    JButton sub = new JButton("Submit details");
    JLabel taxIncLabel = new JLabel("This is your taxable income:  ");
    JTextField taxIncTxt = new JTextField(10);
    JLabel taxToPayLabel = new JLabel("This is the amount of tax you pay:  ");
    JTextField taxToPayTxt = new JTextField(10);

    public static void main(String[] args) {
        TaxGUI tg = new TaxGUI();
        tg.setVisible(true);
    }

    public TaxGUI() {
        setLayout(new FlowLayout());
        setSize(350, 250);
        setTitle("Taxing");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        status.add(marriedRB);
        status.add(singleRB);
        add(payLabel);
        add(payTxt);
        add(marriedRB);
        add(singleRB);
        add(numKidsLabel);
        add(numKidsTxt);
        add(sub);
        add(taxIncLabel);
        add(taxIncTxt);
        add(taxToPayLabel);
        add(taxToPayTxt);
        sub.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e) {
        DecimalFormat pounds = new DecimalFormat("£###,##0.00");
        int t = Integer.parseInt(payTxt.getText());
        boolean m = marriedRB.isSelected();
        int n = Integer.parseInt(numKidsTxt.getText());
        double net = TaxWorkout.calcTaxInc(t, m, n);
        taxIncTxt.setText(pounds.format(net));
        double tax = TaxWorkout.calcTaxPay(net);
        taxToPayTxt.setText(pounds.format(tax));
    }
}

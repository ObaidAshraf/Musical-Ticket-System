package ch08_auxiliaryclasses.taxworkout;

public class TaxWorkOut2 {
    //sets up the constant values for allowance s and tax rates

    static final int MARRIED_ALLOWANCE = 3000;
    static final int SINGLE_ALLOWANCE = 2000;
    static final double BASIC_TAX_RATE = 0.2;
    static final double MIDDLE_TAX_RATE = 0.4;
    static final double UPPER_TAX_RATE = 0.6;
    //the data members of the class
    int gross;
    boolean isMarried;
    int noOfKids;
    //the constructor of the class with 3 paramenters

    public TaxWorkOut2(int gross, boolean isMarried, int noOfKids) {
        /*assigning the parameter values used when making an object of this class
        to its data members e.g. this.gross is given the value gross received when
        the object is constructed  so if taxWorkOut = new TaxWorkOut2(t, m, n) this has the
        effect of making this.gross = t*/
        this.gross = gross;
        this.isMarried = isMarried;
        this.noOfKids = noOfKids;
    }

    public double taxableIncome() {

        //gross is the datamember value assigned in the class constructor
        //return is fed back to calling method class
        if (isMarried) {
            return gross - MARRIED_ALLOWANCE - noOfKids * 500;
        } else {
            return gross - SINGLE_ALLOWANCE - noOfKids * 500;
        }
    }

    public double taxDue() {
        //net is the return from taxableIncome method
        double net = taxableIncome();
        if (net < 20000) {
            return net * BASIC_TAX_RATE;
        } else if (net < 40000) {
            net = net - 20000;
            return net * MIDDLE_TAX_RATE + 4000;
        } else {
            net = net - 40000;
            return net * MIDDLE_TAX_RATE + 12000;
        }
    }
}

package ch08_auxiliaryclasses.taxworkout;

public class TaxWorkout {
//Kates version

    static final int MARRIED_ALLOWANCE = 3000;
    static final int SINGLE_ALLOWANCE = 2000;
    static final double BASIC_TAX_RATE = 0.2;
    static final double MIDDLE_TAX_RATE = 0.4;
    static final double UPPER_TAX_RATE = 0.6;

    public static double calcTaxInc(int gross, boolean mstatus, int kids) {
        if (mstatus) {
            return gross - MARRIED_ALLOWANCE - kids * 500;
        } else {
            return gross - SINGLE_ALLOWANCE - kids * 500;
        }
    }

    public static double calcTaxPay(double net) {
        if (net < 20000) {
            return net * BASIC_TAX_RATE;
        } else if (net < 40000) {
            net = net - 20000;
            return net * MIDDLE_TAX_RATE + 4000;
        } else {
            net = net - 40000;
            return net * MIDDLE_TAX_RATE + 12000;
        }
    }
}

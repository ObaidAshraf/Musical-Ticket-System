package ch08_auxiliaryclasses.taxworkout;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.text.DecimalFormat;

public class TaxGUI2 extends JFrame
        implements ActionListener {
    //creates all the GUI objects

    JLabel payLabel = new JLabel("Enter you gross annual pay:  ");
    JTextField payTxt = new JTextField(10);
    JRadioButton marriedRB = new JRadioButton("click here if married", false);
    JRadioButton singleRB = new JRadioButton("click here if not married", true);
    ButtonGroup status = new ButtonGroup();
    JLabel numKidsLabel = new JLabel("Enter the number of children you have:  ");
    JTextField numKidsTxt = new JTextField(10);
    JButton sub = new JButton("Submit details");
    JLabel taxIncLabel = new JLabel("This is your taxable income:  ");
    JTextField taxIncTxt = new JTextField(10);
    JLabel taxToPayLabel = new JLabel("This is the amount of tax you pay:  ");
    JTextField taxToPayTxt = new JTextField(10);

    public static void main(String[] args) {
        //constructs a new class which will be visible
        TaxGUI2 tg = new TaxGUI2();
        tg.setVisible(true);
    }
    //the constructor for the class

    public TaxGUI2() {
        //the size and set up of the content pane
        setLayout(new FlowLayout());
        setSize(350, 250);
        setTitle("Taxing");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        //adding all the buttons etc
        status.add(marriedRB);
        status.add(singleRB);
        add(payLabel);
        add(payTxt);
        add(marriedRB);
        add(singleRB);
        add(numKidsLabel);
        add(numKidsTxt);
        add(sub);
        add(taxIncLabel);
        add(taxIncTxt);
        add(taxToPayLabel);
        add(taxToPayTxt);
        //setting up the listener to take in the submit button click
        sub.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e) {
        //what has to happen when the submit button is clicked
        DecimalFormat poundsFormat = new DecimalFormat("£###,##0.00");
        //'reading' the pay and turning the String into an integer to be calles t
        int t = Integer.parseInt(payTxt.getText());
        //checking which radio button is selected and putting married true or false to m
        boolean m = marriedRB.isSelected();
        //'reading' the number of kids and turning the String into an integer to be calles n
        int n = Integer.parseInt(numKidsTxt.getText());
        //creates an instance (object) of the TaxWorkOut2 class with the data received
        TaxWorkOut2 taxWorkOut = new TaxWorkOut2(t, m, n);
        //uses the method 'taxableIncome' of the object taxWorkOut to get the taxable income and call it net
        double net = taxWorkOut.taxableIncome();
        //put the value net into the text field using format to change it from double
        taxIncTxt.setText(poundsFormat.format(net));
        //uses the method 'taxDue' of the object to get the tax due and call it tax
        double tax = taxWorkOut.taxDue();
        //put the value tax into the text field using format to change it from double
        taxToPayTxt.setText(poundsFormat.format(tax));
    }
}

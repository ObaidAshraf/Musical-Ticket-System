package ch08_auxiliaryclasses.carpetcalculator;

class CarpetCalculator {

    private double length; // metre
    private double width;  // metre
    private double pricePerSquareMetre;

    // some useful constants
    static final double CENTIMETRES_PER_METRE = 100.0;

    // the default constructor is used so we need set methods
    public void setLength(double l) {
        length = l;
    }

    public void setWidth(double w) {
        width = w;
    }

    public void setLength(int metres, int centimetres) {
        length = metres + centimetres / CENTIMETRES_PER_METRE;
    }

    public void setWidth(int metres, int centimetres) {
        width = metres + centimetres / CENTIMETRES_PER_METRE;
    }

    public void setPricePerSquareMetre(double price) {
        pricePerSquareMetre = price;
    }

    // get methods
    public double getPricePerSquareMetre() {
        return pricePerSquareMetre;
    }

    public double getArea() {
        return length * width;
    }

    // method to calculate the cost of the carpet
    public double calculateCost() {
        return pricePerSquareMetre * getArea();
    }
}
package ch08_auxiliaryclasses.carpetcalculator;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.text.DecimalFormat;

public class CarpetCalculatorApp2 extends JFrame
        implements ItemListener, ChangeListener {

    DecimalFormat pounds = new DecimalFormat("£#,##0.00");
    DecimalFormat twoDP = new DecimalFormat("#,##0.00");

    // Constants for the costs of the different carpet types
    static final double LUXURY_COST = 27.95;
    static final double ECONOMY_COST = 15.95;

    // Swing controls used
    JRadioButton luxury = new JRadioButton("Luxury", true);
    JRadioButton economy = new JRadioButton("Economy", false);
    ButtonGroup b = new ButtonGroup();
    JTextField areaTxt = new JTextField(5);
    JTextField costTxt = new JTextField(5);

    // Spinners allow safe entry of a number in a range.
    // They are a bit fiddly to use, but worth the effort.
    // See the Java API documentation for details.
    // This version uses separate spinners for metres and centimetres
    // which give integer values from 0 to 50 (0 to 99)
    JSpinner lengthMetresSp = new JSpinner(new SpinnerNumberModel(0, 0, 50, 1));
    JSpinner lengthCentimetresSp = new JSpinner(new SpinnerNumberModel(0, 0, 99, 1));
    JSpinner widthMetresSp = new JSpinner(new SpinnerNumberModel(0, 0, 50, 1));
    JSpinner widthCentimetresSp = new JSpinner(new SpinnerNumberModel(0, 0, 99, 1));
    CarpetCalculator calculator = new CarpetCalculator();

    public static void main(String[] args) {
        new CarpetCalculatorApp2();
    }

    public CarpetCalculatorApp2() {
        setLayout(new BorderLayout());

        JPanel top = new JPanel();
        top.add(new JLabel("Length (m)"));
        top.add(lengthMetresSp);
        top.add(new JLabel("   Length (cm)"));
        top.add(lengthCentimetresSp);
        top.add(new JLabel("   Width (m)"));
        top.add(widthMetresSp);
        top.add(new JLabel("   Width (cm)"));
        top.add(widthCentimetresSp);
        lengthMetresSp.addChangeListener(this);
        lengthCentimetresSp.addChangeListener(this);
        widthMetresSp.addChangeListener(this);
        widthCentimetresSp.addChangeListener(this);
        add("North", top);

        JPanel middle = new JPanel();
        b.add(luxury);
        b.add(economy);
        middle.add(luxury);
        middle.add(economy);
        luxury.addItemListener(this);
        economy.addItemListener(this);
        add("Center", middle);

        JPanel bottom = new JPanel();
        bottom.add(new Label("Area (m sq)"));
        bottom.add(areaTxt);
        bottom.add(new Label("   Cost"));
        bottom.add(costTxt);
        areaTxt.setEditable(false);
        costTxt.setEditable(false);
        add("South", bottom);
        setSize(500, 135);
        setTitle("Carpet cost calculator version 2");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        calculator.setPricePerSquareMetre(LUXURY_COST);
        reset();
        setVisible(true);
        setResizable(false);
    }

    // event handler for the radio buttons
    public void itemStateChanged(ItemEvent e) {
        if (luxury.isSelected()) {
            calculator.setPricePerSquareMetre(LUXURY_COST);
        } else {
            calculator.setPricePerSquareMetre(ECONOMY_COST);
        }
        reset();
    }

    // event handler for the spinners
    public void stateChanged(ChangeEvent e) {
        if (e.getSource() == lengthMetresSp || e.getSource() == lengthCentimetresSp) {
            int metres = Integer.parseInt("" + lengthMetresSp.getValue());
            int centimetres = Integer.parseInt("" + lengthCentimetresSp.getValue());
            calculator.setLength(metres, centimetres);
        } else {
            int metres = Integer.parseInt("" + widthMetresSp.getValue());
            int centimetres = Integer.parseInt("" + widthCentimetresSp.getValue());
            calculator.setWidth(metres, centimetres);
        }
        reset();
    }

    // auxiliary method to reset the area and cost text fields
    private void reset() {
        areaTxt.setText(twoDP.format(calculator.getArea()));
        costTxt.setText(pounds.format(calculator.calculateCost()));
    }
}
package ch08_auxiliaryclasses.feesworkout;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.text.DecimalFormat;

public class FeesGUI2 extends JFrame
        implements ActionListener {

    JLabel nameLabel = new JLabel("Enter your family name:  ");
    JTextField nameTxt = new JTextField(10);
    JRadioButton homeRB = new JRadioButton("click here if home student", false);
    JRadioButton overseasRB = new JRadioButton("click here if overseas", true);
    ButtonGroup status = new ButtonGroup();
    JLabel numCoursesLabel = new JLabel("Enter the number of courses you are taking:  ");
    JTextField numCoursesTxt = new JTextField(4);
    JButton sub = new JButton("Submit details");
    JLabel feesLabel = new JLabel("The fees for this year are:  ");
    JTextField feesTxt = new JTextField(10);
    JButton clear = new JButton("CLEAR");

    public static void main(String[] args) {
        FeesGUI2 tg = new FeesGUI2();
    }

    public FeesGUI2() {
        setLayout(new FlowLayout());
        setSize(300, 250);
        setTitle("FEES");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        status.add(homeRB);
        status.add(overseasRB);
        add(nameLabel);
        add(nameTxt);
        add(homeRB);
        add(overseasRB);
        add(numCoursesLabel);
        add(numCoursesTxt);
        add(sub);
        add(feesLabel);
        add(feesTxt);
        add(clear);
        sub.addActionListener(this);
        clear.addActionListener(this);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == sub) {
            DecimalFormat pounds = new DecimalFormat("£###,##0.00");
            String n = nameTxt.getText();
            boolean h = homeRB.isSelected();
            int c = Integer.parseInt(numCoursesTxt.getText());

            FeesWorkout2 feesWorker = new FeesWorkout2(n, h, c);

            double fee = feesWorker.calcFees();
            feesTxt.setText(pounds.format(fee));
        } else if (e.getSource() == clear) {
            nameTxt.setText("");
            numCoursesTxt.setText("");
            feesTxt.setText("");
        }
    }
}

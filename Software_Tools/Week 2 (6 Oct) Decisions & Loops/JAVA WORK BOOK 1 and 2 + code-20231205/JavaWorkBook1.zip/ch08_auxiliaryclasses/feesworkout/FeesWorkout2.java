package ch08_auxiliaryclasses.feesworkout;

class FeesWorkout2 {

    static final int COURSE_HOME = 600;
    static final int COURSE_OVERSEAS = 2000;
    String name;
    boolean rstatus;
    int courses;

    public FeesWorkout2(String name, boolean rstatus, int courses) {
        this.name = name;
        this.rstatus = rstatus;
        this.courses = courses;
    }

    public double calcFees() {
        if ("Finney".equalsIgnoreCase(name)) {
            return 0;
        } else if (rstatus) {
            return COURSE_HOME * courses;
        } else {
            return COURSE_OVERSEAS * courses;
        }
    }
}

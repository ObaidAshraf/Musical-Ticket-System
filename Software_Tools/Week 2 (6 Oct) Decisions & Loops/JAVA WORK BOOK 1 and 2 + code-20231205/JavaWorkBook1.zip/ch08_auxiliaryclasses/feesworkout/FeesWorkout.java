package ch08_auxiliaryclasses.feesworkout;

class FeesWorkout {

    public static double calcFees(String name, boolean rstatus, int courses) {
        final int COURSE_HOME = 600;
        final int COURSE_OVERSEAS = 2000;

        if ("Finney".equalsIgnoreCase(name)) {
            return 0;
        } else if (rstatus) {
            return COURSE_HOME * courses;
        } else {
            return COURSE_OVERSEAS * courses;
        }
    }
}

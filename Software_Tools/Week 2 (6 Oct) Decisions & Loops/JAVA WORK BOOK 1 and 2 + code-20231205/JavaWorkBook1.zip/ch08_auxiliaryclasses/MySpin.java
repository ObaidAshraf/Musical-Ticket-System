package ch08_auxiliaryclasses;

import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;

public class MySpin extends JFrame
        implements ChangeListener {

    JLabel ageLbl = new JLabel("pick your age");
    JSpinner ageSp = new JSpinner(new SpinnerNumberModel(0, 0, 100, 1));
    JTextField showTxt = new JTextField(20);

    public static void main(String[] args) {
        MySpin sp = new MySpin();
    }

    public MySpin() {
        setLayout(new FlowLayout());
        setSize(300, 150);
        setTitle("Spin");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        add(ageLbl);
        add(ageSp);
        add(showTxt);
        ageSp.addChangeListener(this);
        setVisible(true);
    }

    public void stateChanged(ChangeEvent e) {
        showTxt.setText("you don't look  " + ageSp.getValue() + "   years old");
    }
}

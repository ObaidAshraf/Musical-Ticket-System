package ch08_auxiliaryclasses;

import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;

public class SpinEx extends JFrame
        implements ChangeListener {
    //creating a spinner going from 1-10 in 1's

    JSpinner exampleSp = new JSpinner(new SpinnerNumberModel(0, 0, 20, 1));
    JLabel icon = new JLabel(new ImageIcon("MNSTRGUY.gif"));

    public static void main(String[] args) {
        SpinEx se = new SpinEx();
    }

    public SpinEx() {
        setLayout(new FlowLayout());
        setSize(400, 300);
        setTitle("Unlucky");
        add(exampleSp);
        exampleSp.addChangeListener(this);
        add(icon);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        icon.setVisible(false);
        setVisible(true);
    }

    public void stateChanged(ChangeEvent e) {

        int number = Integer.parseInt("" + exampleSp.getValue());
        if (number == 13) {
            icon.setVisible(true);
        } else {
            icon.setVisible(false);
        }

    }
}

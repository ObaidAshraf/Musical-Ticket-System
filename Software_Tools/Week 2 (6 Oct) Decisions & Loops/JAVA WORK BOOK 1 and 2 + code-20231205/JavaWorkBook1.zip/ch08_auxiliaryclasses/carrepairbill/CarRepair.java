package ch08_auxiliaryclasses.carrepairbill;

class CarRepair {
    // private instance variables

    private double parts,  hours,  rate,  vat;

    // public no-argument constructor
    public CarRepair() {
    }

    // public constructor with four arguments
    public CarRepair(double p, double h, double r, double v) {
        parts = p;
        hours = h;
        rate = r;
        vat = v;
    }

    // public 'set' methods
    public void setParts(double p) {
        parts = p;
    }

    public void setHours(double h) {
        hours = h;
    }

    public void setRate(double r) {
        rate = r;
    }

    public void setVat(double v) {
        vat = v;
    }

    // public method to calculate the bill
    public double calculateBill() {
        double bill = parts + hours * rate;
        bill *= 1 + vat / 100.0;
        return bill;
    }
}
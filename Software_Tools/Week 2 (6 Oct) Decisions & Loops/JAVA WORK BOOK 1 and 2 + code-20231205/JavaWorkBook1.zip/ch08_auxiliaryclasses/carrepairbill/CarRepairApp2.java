package ch08_auxiliaryclasses.carrepairbill;

import java.awt.*;
import java.text.*;
import javax.swing.*;
import java.awt.event.*;

public class CarRepairApp2 extends JFrame
        implements ActionListener {

    DecimalFormat pounds = new DecimalFormat("£#,##0.00");
    JTextField partsTxt = new JTextField();
    JTextField hoursTxt = new JTextField();
    JTextField rateTxt = new JTextField("20");
    JTextField vatTxt = new JTextField("17.5");
    JTextField billTxt = new JTextField();
    JButton calcBtn = new JButton("Calculate Bill");
    double parts, hours, rate, vat;

    public static void main(String[] args) {
        new CarRepairApp2();
    }

    public CarRepairApp2() {
        setLayout(new BorderLayout());
        setTitle("Car Repair Calculator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setSize(300, 250);
        add("North", new JPanel());
        add("East", new JPanel());
        add("West", new JPanel());
        JPanel middle = new JPanel();
        middle.setLayout(new GridLayout(5, 2, 10, 10));
        middle.add(new JLabel("Cost of parts £   ", SwingConstants.RIGHT));
        middle.add(partsTxt);
        middle.add(new JLabel("Hours worked   ", SwingConstants.RIGHT));
        middle.add(hoursTxt);
        middle.add(new JLabel("Hourly rate £   ", SwingConstants.RIGHT));
        middle.add(rateTxt);
        middle.add(new JLabel("VAT %   ", SwingConstants.RIGHT));
        middle.add(vatTxt);
        middle.add(new JLabel("Your Bill   ", SwingConstants.RIGHT));
        middle.add(billTxt);
        billTxt.setEditable(false);
        add("Center", middle);
        JPanel bottom = new JPanel();
        bottom.add(calcBtn);
        calcBtn.addActionListener(this);
        add("South", bottom);
        setVisible(true);
        setResizable(false);
    }

    public void actionPerformed(ActionEvent e) {
        // Read the input fields, trapping errors
        try {
            parts = Double.parseDouble(partsTxt.getText());
            hours = Double.parseDouble(hoursTxt.getText());
            rate = Double.parseDouble(rateTxt.getText());
            vat = Double.parseDouble(vatTxt.getText());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Bad input, try again");
            return; // return from actionPerformed
        }

        // Create a new CarRepair object to calculate the bill
        // using the no-argument constructor and the set methods
        CarRepair c = new CarRepair();
        c.setParts(parts);
        c.setHours(hours);
        c.setRate(rate);
        c.setVat(vat);
        double bill = c.calculateBill();
        billTxt.setText(pounds.format(bill));
    }
}
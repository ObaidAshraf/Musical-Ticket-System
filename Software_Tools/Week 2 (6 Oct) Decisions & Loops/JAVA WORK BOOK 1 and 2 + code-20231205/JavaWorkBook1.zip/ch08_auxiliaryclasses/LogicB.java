package ch08_auxiliaryclasses;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class LogicB extends JFrame
        implements ActionListener {

    JLabel numOneLabel = new JLabel("Enter your first number:  ");
    JTextField numOneTxt = new JTextField(3);
    JLabel numTwoLabel = new JLabel("Enter your second number:  ");
    JTextField numTwoTxt = new JTextField(3);
    JTextArea commentTxt = new JTextArea(2, 20);
    JButton sumBtn = new JButton("ADD");
    JButton multBtn = new JButton("MULTIPLY");

    public static void main(String[] args) {
        LogicB jf = new LogicB();
    }

    public LogicB() {
        setLayout(new FlowLayout());
        setSize(600, 200);
        setTitle("Add or Multiply?");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        add(numOneLabel);
        add(numOneTxt);
        add(numTwoLabel);
        add(numTwoTxt);
        add(sumBtn);
        add(multBtn);
        add(commentTxt);
        sumBtn.addActionListener(this);
        multBtn.addActionListener(this);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        int numOne = Integer.parseInt(numOneTxt.getText());
        int numTwo = Integer.parseInt(numTwoTxt.getText());
        int result = 0;
        String operation = "";
        if (e.getSource() == sumBtn) {
            operation = "sum";
            result = numOne + numTwo;
        }
        if (e.getSource() == multBtn) {
            operation = "product";
            result = numOne * numTwo;
        }

        String numTxt = Integer.toString(result);
        String message = "The " + operation + " of your two numbers is \n " + numTxt;
        commentTxt.setText(message);
    }
}

package ch08_auxiliaryclasses;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class LogicD extends JFrame
        implements ActionListener {

    JLabel hoursLabel = new JLabel("Enter your hours worked:  ");
    JTextField hoursTxt = new JTextField(3);
    JLabel rateLabel = new JLabel("Enter your hourly rate:  ");
    JTextField rateTxt = new JTextField(3);
    JTextArea wageTxt = new JTextArea(2, 20);
    JButton sumBtn = new JButton("SUBMIT");

    public static void main(String[] args) {
        LogicD jf = new LogicD();
    }

    public LogicD() {
        setLayout(new FlowLayout());
        setSize(600, 200);
        setTitle("Overtime pay");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        add(hoursLabel);
        add(hoursTxt);
        add(rateLabel);
        add(rateTxt);
        add(sumBtn);
        add(wageTxt);
        sumBtn.addActionListener(this);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        Double wage = 0.0;
        int numOne = Integer.parseInt(hoursTxt.getText());
        double numTwo = Double.parseDouble(rateTxt.getText());
        if (numOne < 40) {
            wage = numOne * numTwo;
        } else {
            int overtime = numOne - 40;
            wage = 40 * numTwo + overtime * numTwo * 1.5;
        }
        String wageStr = Double.toString(wage);
        wageStr = "£" + wageStr;
        String message = "Your wages are \n " + wageStr;
        wageTxt.setText(message);
    }
}

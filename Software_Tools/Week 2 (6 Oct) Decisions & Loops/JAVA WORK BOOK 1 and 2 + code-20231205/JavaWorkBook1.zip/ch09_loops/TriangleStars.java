package ch09_loops;

import javax.swing.JOptionPane;
import static java.lang.System.*;

class TriangleStars {

    public static void main(String[] args) {
        String numberStr =
                JOptionPane.showInputDialog("how many?");
        int n = Integer.parseInt(numberStr);
        for (int i = 0; i < n; i++) {
            for (int j = 0; j <= i; j++) {
                out.print("*");
            }
            out.println();
        }
    }
}

package ch09_loops;

import java.awt.*;
import javax.swing.*;

public class AnimApp extends JComponent implements Runnable {

    Image[] images = new Image[14];
    int frame = 0;

    public void paint(Graphics g) {
        Image image = images[frame];
        if (image != null) {
            // Draw the current image
            int x = 0;
            int y = 0;
            g.drawImage(image, x, y, this);
        }
    }

    public void run() {
        // Load the array of images
        images[0] = new ImageIcon("T0.gif").getImage();
        images[1] = new ImageIcon("T1.gif").getImage();
        images[2] = new ImageIcon("T2.gif").getImage();
        images[3] = new ImageIcon("T3.gif").getImage();
        images[4] = new ImageIcon("T4.gif").getImage();
        images[5] = new ImageIcon("T5.gif").getImage();
        images[6] = new ImageIcon("T6.gif").getImage();
        images[7] = new ImageIcon("T7.gif").getImage();
        images[8] = new ImageIcon("T8.gif").getImage();
        images[9] = new ImageIcon("T9.gif").getImage();
        images[10] = new ImageIcon("T10.gif").getImage();
        images[11] = new ImageIcon("T11.gif").getImage();
        images[12] = new ImageIcon("T12.gif").getImage();
        images[13] = new ImageIcon("T13.gif").getImage();
        // Display each image for 1/10 second
        int delay = 100;    // 1/10 second

        try {
            while (true) {
                // Move to the next image
                frame = (frame + 1) % images.length;

                // Causes the paint() method to be called
                repaint();

                // Wait
                Thread.sleep(delay);
            }
        } catch (Exception e) {
        }
    }

    public static void main(String[] args) {
        AnimApp app = new AnimApp();

        // Display the animation in a frame
        JFrame frame = new JFrame();
        frame.getContentPane().add(app);
        frame.setSize(250, 250);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        (new Thread(app)).start();
    }
}

package ch09_loops;

class Search {

    public static void main(String[] args) {
        int h = 5;
        int r = 3;
        for (int i = 0; i < h; i++) {
            for (int j = 0; j < r; j++) {
                System.out.print("No one here  ");
            }
            System.out.println();
        }
    }
}


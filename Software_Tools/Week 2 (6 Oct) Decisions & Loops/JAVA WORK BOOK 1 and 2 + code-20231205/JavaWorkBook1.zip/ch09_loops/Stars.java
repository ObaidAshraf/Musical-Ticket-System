package ch09_loops;

import javax.swing.JOptionPane;
import static java.lang.System.*;

class Stars {

    public static void main(String[] args) {
        String numberStr =
                JOptionPane.showInputDialog("how many?");
        int n = Integer.parseInt(numberStr);
        int counter = 0;
        while (counter < n) {
            out.print("*");
            counter++;
        }
        out.println();
    }
}

package ch07_gui2;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class InOutChoice extends JFrame
        implements ActionListener {

    JButton sub1 = new JButton("Press me!");
    JButton sub2 = new JButton("No,  press me!");
    JLabel messageLbl = new JLabel("A message for you:  ");
    JTextField messageTxt = new JTextField(10);

    public static void main(String[] args) {
        InOutChoice jf = new InOutChoice();
        jf.setVisible(true);
    }

    public InOutChoice() {
        setLayout(new FlowLayout());
        setSize(300, 100);
        setTitle("Left or Right?");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        add(sub1);
        add(sub2);
        add(messageLbl);
        add(messageTxt);
        sub1.addActionListener(this);
        sub2.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == sub1) {
            messageTxt.setText("you prefer the left");
        }
        if (e.getSource() == sub2) {
            messageTxt.setText("you like the right");
        }
    }
}

package ch07_gui2;

import javax.swing.*;

public class Placing extends JFrame {

    JButton placeBtn = new JButton("Place Me");

    public static void main(String[] args) {
        Placing jf = new Placing();
        jf.setVisible(true);
    }

    public Placing() {
        //setting layout manager to null allows placing
        setLayout(null);
        setSize(200, 150);
        setTitle("Placing");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        placeBtn.setBounds(25, 80, 150, 30);
        add(placeBtn);
        setResizable(false);

    }
}

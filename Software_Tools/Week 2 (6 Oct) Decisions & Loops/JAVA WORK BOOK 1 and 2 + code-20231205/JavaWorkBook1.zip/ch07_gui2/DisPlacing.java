package ch07_gui2;

import javax.swing.*;
import java.awt.event.*;

public class DisPlacing extends JFrame
        implements ActionListener {

    JButton placeBtn = new JButton("Place Me");

    public static void main(String[] args) {
        DisPlacing jf = new DisPlacing();
        jf.setVisible(true);
    }

    public DisPlacing() {
        //setting layout manager to null allows placing
        setLayout(null);
        setSize(200, 150);
        setTitle("DisPlacing");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        placeBtn.setBounds(25, 80, 150, 30);
        add(placeBtn);
        placeBtn.addActionListener(this);
        setResizable(false);

    }

    public void actionPerformed(ActionEvent e) {
        placeBtn.setBounds(5, 20, 175, 30);
        add(placeBtn);
    }
}

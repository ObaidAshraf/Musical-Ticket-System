package ch07_gui2;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Vehicles extends JFrame
        implements ActionListener {

    JTextField carsTxt = new JTextField(3);
    JTextField vansTxt = new JTextField(3);
    JButton carsBtn = new JButton("Car");
    JButton vansBtn = new JButton("Van");
    JButton reset = new JButton("Reset");
    int cars = 0, vans = 0; // counters

    public static void main(String[] args) {
        new Vehicles();
    }

    public Vehicles() {
        setLayout(new BorderLayout());
        setSize(400, 140);
        setTitle("Car and van counter");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        JPanel top = new JPanel();
        top.setLayout(new FlowLayout());
        top.add(new Label("Cars:"));
        top.add(carsTxt);
        carsTxt.setEditable(false);
        top.add(new Label("          Vans:"));
        top.add(vansTxt);
        vansTxt.setEditable(false);
        carsTxt.setText("0");
        vansTxt.setText("0");
        add("North", top);
        JPanel bottom = new JPanel();
        bottom.setLayout(new FlowLayout());
        bottom.add(carsBtn);
        bottom.add(vansBtn);
        bottom.add(reset);
        carsBtn.addActionListener(this);
        vansBtn.addActionListener(this);
        reset.addActionListener(this);
        add("South", bottom);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == carsBtn) {
            cars++;
        } else if (e.getSource() == vansBtn) {
            vans++;
        } else if (e.getSource() == reset) {
            cars = vans = 0;
        }
        carsTxt.setText("" + cars);
        vansTxt.setText("" + vans);
    }
} 

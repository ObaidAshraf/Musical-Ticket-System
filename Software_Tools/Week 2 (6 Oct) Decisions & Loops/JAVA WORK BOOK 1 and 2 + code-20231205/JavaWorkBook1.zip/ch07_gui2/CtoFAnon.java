package ch07_gui2;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class CtoFAnon extends JFrame {
    // uses anonymous inner classes for event handling

    JTextField centigradeTxt = new JTextField(2);
    JTextField fahrenheitTxt = new JTextField(2);
    JScrollBar centigradeScr =
            new JScrollBar(JScrollBar.HORIZONTAL, 0, 0, 0, 100);
    JButton resetBtn = new JButton("Reset");
    JPanel top = new JPanel();
    JPanel middle = new JPanel();

    public static void main(String[] args) {
        CtoFAnon jf = new CtoFAnon();
    }

    public CtoFAnon() {
        reset();
        setLayout(new BorderLayout());
        setSize(500, 140);
        setTitle("°C to °F");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        top.setLayout(new FlowLayout());
        top.add(resetBtn);
        resetBtn.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                reset();
            }
        });
        middle.setLayout(new FlowLayout());
        middle.add(new Label("°C"));
        middle.add(centigradeTxt);
        middle.add(new Label("                          °F"));
        middle.add(fahrenheitTxt);
        add("South", centigradeScr);
        centigradeScr.setBlockIncrement(5);
        centigradeScr.addAdjustmentListener(new AdjustmentListener() {

            public void adjustmentValueChanged(AdjustmentEvent e) {
                int centigrade = centigradeScr.getValue();
                // convert to the nearest °F
                int fahrenheit = 32 + Math.round(centigrade * 1.8f);
                centigradeTxt.setText("" + centigrade);
                fahrenheitTxt.setText("" + fahrenheit);
            }
        });
        add("Center", middle);
        add("North", top);
        setResizable(false);
        setVisible(true);
    }

    private void reset() {
        centigradeTxt.setText("0");
        fahrenheitTxt.setText("32");
        centigradeScr.setValue(0);
    }
}
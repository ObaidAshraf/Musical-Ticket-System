package ch07_gui2;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class LogicC extends JFrame
        implements ActionListener {

    JLabel hoursLabel = new JLabel("Enter your hours worked:  ");
    JTextField hoursTxt = new JTextField(3);
    JLabel rateLabel = new JLabel("Enter your hourly rate:  ");
    JTextField rateTxt = new JTextField(3);
    JTextArea wageTxt = new JTextArea(2, 20);
    JButton sumBtn = new JButton("SUBMIT");

    public static void main(String[] args) {
        LogicC jf = new LogicC();
    }

    public LogicC() {
        setLayout(new FlowLayout());
        setSize(600, 200);
        setTitle("Wages");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        add(hoursLabel);
        add(hoursTxt);
        add(rateLabel);
        add(rateTxt);
        add(sumBtn);
        add(wageTxt);
        sumBtn.addActionListener(this);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        // put code here
    }
}

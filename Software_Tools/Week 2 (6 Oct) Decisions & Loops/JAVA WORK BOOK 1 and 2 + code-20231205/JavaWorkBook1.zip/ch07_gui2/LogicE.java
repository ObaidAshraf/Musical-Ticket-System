package ch07_gui2;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class LogicE extends JFrame
        implements ActionListener, AdjustmentListener {

    JLabel hoursLabel = new JLabel("Enter your hours worked:  ");
    JTextField hoursTxt = new JTextField(3);
    JLabel rateLabel = new JLabel("Move for your hourly rate:  ");
    JScrollBar rateScr =
            new JScrollBar(JScrollBar.HORIZONTAL, 5, 0, 1, 50);
    JButton resetBtn = new JButton("Reset");
    JTextArea wageTxt = new JTextArea(2, 20);
    JLabel rateChosenLabel = new JLabel("Hourly rate:  ");
    JTextField rateTxt = new JTextField(3);
    JPanel top = new JPanel();
    JPanel middle = new JPanel();
    JPanel bottom = new JPanel();

    public static void main(String[] args) {
        LogicE jf = new LogicE();
    }

    public LogicE() {
        setLayout(new BorderLayout());
        setSize(300, 200);
        setTitle("Scrolling Logic");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        top.setLayout(new FlowLayout());
        top.add(resetBtn);
        resetBtn.addActionListener(this);
        middle.setLayout(new FlowLayout());
        middle.add(hoursLabel);
        middle.add(hoursTxt);
        middle.add(wageTxt);
        middle.add(rateChosenLabel);
        middle.add(rateTxt);

        bottom.setLayout(new FlowLayout());
        bottom.add(rateLabel);
        bottom.add(rateScr);
        rateScr.setBlockIncrement(5);
        rateScr.addAdjustmentListener(this);
        add("North", top);
        add("Center", middle);
        add("South", bottom);
        setResizable(false);
        hoursTxt.setText("0");
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        //put code here
    }

    public void adjustmentValueChanged(AdjustmentEvent e) {
        // put code here
    }
}

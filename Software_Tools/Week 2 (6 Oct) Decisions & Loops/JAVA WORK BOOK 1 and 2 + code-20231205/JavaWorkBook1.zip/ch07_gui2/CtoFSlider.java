package ch07_gui2;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;

public class CtoFSlider extends JFrame
        implements ActionListener, ChangeListener {

    JTextField centigradeTxt = new JTextField(2);
    JTextField fahrenheitTxt = new JTextField(2);
    JSlider centigradeSl = new JSlider(0, 100, 0);
    JButton resetBtn = new JButton("Reset");
    JPanel bottom = new JPanel();
    JPanel middle = new JPanel();

    public static void main(String[] args) {
        CtoFSlider jf = new CtoFSlider();
    }

    public CtoFSlider() {
        reset();
        setLayout(new BorderLayout());
        setSize(500, 140);
        setTitle("°C to °F");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        bottom.setLayout(new FlowLayout());
        bottom.add(resetBtn);
        resetBtn.addActionListener(this);
        middle.setLayout(new FlowLayout());
        middle.add(new Label("°C"));
        middle.add(centigradeTxt);
        middle.add(new Label("                          °F"));
        middle.add(fahrenheitTxt);
        centigradeSl.setMajorTickSpacing(10);
        centigradeSl.setMinorTickSpacing(1);
        centigradeSl.setPaintTicks(true);
        centigradeSl.setPaintLabels(true);
        add("North", centigradeSl);
        centigradeSl.addChangeListener(this);
        add("Center", middle);
        add("South", bottom);
        setResizable(false);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        reset();
    }

    public void stateChanged(ChangeEvent e) {
        int centigrade = centigradeSl.getValue();
        // convert to the nearest °F
        int fahrenheit = 32 + Math.round(centigrade * 1.8f);
        centigradeTxt.setText("" + centigrade);
        fahrenheitTxt.setText("" + fahrenheit);
    }

    private void reset() {
        centigradeTxt.setText("0");
        fahrenheitTxt.setText("32");
        centigradeSl.setValue(0);
    }
}
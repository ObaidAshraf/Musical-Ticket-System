package ch01_intro;

import javax.swing.*;

class HelloName {

    public static void main(String[] args) {
        String name;
        name = JOptionPane.showInputDialog("Input?");
        System.out.println("Hello " + name);
    }
}

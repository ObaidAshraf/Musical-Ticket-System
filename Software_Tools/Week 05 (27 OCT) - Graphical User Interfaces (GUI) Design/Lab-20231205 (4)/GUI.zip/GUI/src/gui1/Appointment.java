package gui1;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Appointment
        extends JFrame implements ActionListener {

    JComboBox day = new JComboBox();
    JRadioButton am = new JRadioButton("Morning", true);
    JRadioButton pm = new JRadioButton("Afternoon", false);
    JRadioButton eve = new JRadioButton("Evening", false);
    ButtonGroup timeSlot = new ButtonGroup();
    JTextField bookTxt = new JTextField(15);
    JButton bookBtn = new JButton("Make a booking");

    public static void main(String[] args) {
        new Appointment();
    }

    public Appointment() {
        setLayout(new BorderLayout());
        setSize(400, 150);
        setTitle("Appointment selector");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        JPanel top = new JPanel();
        top.setLayout(new FlowLayout());
        day.addItem("Monday");
        day.addItem("Tuesday");
        day.addItem("Wednesday");
        day.addItem("Thursday");
        day.addItem("Friday");
        top.add(day);
        timeSlot.add(am);
        timeSlot.add(pm);
        timeSlot.add(eve);
        top.add(am);
        top.add(pm);
        top.add(eve);
        add("North", top);
        JPanel middle = new JPanel();
        middle.setLayout(new FlowLayout());
        middle.add(bookTxt);
        add("Center", middle);
        JPanel bottom = new JPanel();
        bottom.setLayout(new FlowLayout());
        bottom.add(bookBtn);
        add("South", bottom);
        bookBtn.addActionListener(this);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        String time;
        if (am.isSelected()) {
            time = " Morning";
        } else if (pm.isSelected()) {
            time = " Afternoon";
        } else {
            time = " Evening";
        }
        bookTxt.setText(day.getSelectedItem() + time);
    }
}

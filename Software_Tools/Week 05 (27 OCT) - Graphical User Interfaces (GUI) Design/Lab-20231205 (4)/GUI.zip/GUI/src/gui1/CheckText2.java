package gui1;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class CheckText2 extends JFrame implements ActionListener {

    JTextField myTxt = new JTextField(30);
    JCheckBox myRedChBx = new JCheckBox("click here for Red");
    JCheckBox myGreenChBx = new JCheckBox("click here for Green");

    public static void main(String[] args) {
        CheckText2 jf = new CheckText2();
    }

    public CheckText2() {
        setLayout(new FlowLayout());
        setSize(400, 120);
        setTitle("Red or Green?");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        add(myTxt);
        add(myRedChBx);
        add(myGreenChBx);
        myRedChBx.addActionListener(this);
        myGreenChBx.addActionListener(this);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == myRedChBx) {
            myTxt.setText("you have chosen Red");
        } else if (e.getSource() == myGreenChBx) {
            myTxt.setText("you have chosen Green");
        }
    }
}

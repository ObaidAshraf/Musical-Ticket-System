package gui1.shapes;

import java.awt.*;
import java.util.*;

class ShapeStack {
// Implements a stack of shapeList
// using an ArrayList

    // Push a shape onto the stack
    public void push(Shape shape) {
        shapeList.add(shape);
    }

    // Pop shape from top of stack
    public void pop() throws Exception {
        if (shapeList.isEmpty()) {
            throw new Exception("Stack underflow");
        } else {
            shapeList.remove(shapeList.size() - 1);
        }
    }

    // Get shape clicked on.
    // Return null if no shape found.
    // Otherwise return shape found closest to top of stack,
    // and move this shape to the top.
    public Shape get(float x, float y) {
        Shape shape;
        int i = shapeList.size();
        while (i-- > 0) {
            shape = shapeList.get(i);
            if (shape.contains(x, y)) // found shape
            {
                shapeList.remove(i);            // these two statements
                shapeList.add(shape);           // move shape to top.
                return shape;
            }
        }
        return null; // not found
    }

    public void draw(Graphics g) {
        // Use a for-each loop (Java v5)
        for (Shape shape : shapeList) {
            shape.draw(g);
        }
    }

    // Define shapeList as a generic (Java v5) collection
    private ArrayList<Shape> shapeList = new ArrayList<Shape>();
}
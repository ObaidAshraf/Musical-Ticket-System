package gui1.shapes;

import java.awt.*;

class Face extends Circle {

    Face(float x, float y, float size, Color color) {
        super(x, y, size, color);
    }

    @Override
    public void draw(Graphics g) {
        float s = size / 12;
        super.draw(g); // outline of face
        Color oldColor = g.getColor();
        if (color == Color.black) {
            g.setColor(Color.white);
        } else {
            g.setColor(Color.black);
        }
        g.fillOval((int) (x + s * 3), (int) (y + s * 3),
                (int) (s * 2), (int) (s * 2)); // left eye
        g.fillOval((int) (x + s * 7), (int) (y + s * 3),
                (int) (s * 2), (int) (s * 2)); // right eye
        g.fillOval((int) (x + s * 5), (int) (y + s * 5),
                (int) (s * 2), (int) (s * 2)); // nose
        g.fillRect((int) (x + s * 4), (int) (y + s * 8),
                (int) (s * 4), (int) s);     // mouth
        g.setColor(oldColor);
    }
}
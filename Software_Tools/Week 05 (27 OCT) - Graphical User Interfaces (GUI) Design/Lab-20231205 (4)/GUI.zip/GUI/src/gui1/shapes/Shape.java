package gui1.shapes;

import java.awt.*;

abstract class Shape {

    // What do our shapes have in common?
    // A top left position, a size and a color, so:
    protected float x,  y,  size;
    protected Color color;

    // Constructor
    Shape(float x, float y, float size, Color color) {
        this.x = x;
        this.y = y;
        this.size = size;
        this.color = color;
    }

    // Change the size of a shape
    public void changeSize(float change) {
        size += change;
        if (size < 1) {
            size = 1; // a negative or zero size doesn't make sense
        }
    }

    // Move shape by an increment x, y
    public void move(float x, float y) {
        this.x += x;
        this.y += y;
    }

    // Abstract method to test whether the point (x, y) lies within the shape
    public abstract boolean contains(float x, float y);

    // Abstract method to draw the shape
    abstract void draw(Graphics g);

    // Note that each subclass MUST implement contains and draw if it is not
    // itself to be abstract
}

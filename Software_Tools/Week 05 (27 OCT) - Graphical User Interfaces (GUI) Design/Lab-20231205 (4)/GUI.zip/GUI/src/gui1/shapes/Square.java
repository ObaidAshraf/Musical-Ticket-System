package gui1.shapes;

import java.awt.*;

class Square extends Shape {

    Square(float x, float y, float size, Color color) {
        super(x, y, size, color);
    }

    public void draw(Graphics g) {
        Color oldColor = g.getColor();
        g.setColor(color);
        g.fillRect((int) x, (int) y, (int) size, (int) size);
        g.setColor(oldColor);
        g.drawRect((int) x, (int) y, (int) size, (int) size);
    }

    public boolean contains(float x, float y) {
        return (this.x <= x) && (this.y <= y) &&
                (x <= this.x + size) && (y <= this.y + size);
    }
}
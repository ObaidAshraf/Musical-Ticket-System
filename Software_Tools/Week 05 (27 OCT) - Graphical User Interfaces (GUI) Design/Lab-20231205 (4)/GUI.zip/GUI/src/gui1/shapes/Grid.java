package gui1.shapes;

import java.awt.*;

class Grid extends Window {

    Grid(float x, float y, float size, Color color) {
        super(x, y, size, color);
    }

    @Override
    public void draw(Graphics g) {
        super.draw(g);
        Color oldColor = g.getColor();
        if (color == Color.black) {
            g.setColor(Color.white);
        } else {
            g.setColor(Color.black);
        }
        g.drawLine((int) (x + size / 4), (int) y,
                (int) (x + size / 4), (int) (y + size));
        g.drawLine((int) (x + 3 * size / 4), (int) y,
                (int) (x + 3 * size / 4), (int) (y + size));
        g.drawLine((int) x, (int) (y + size / 4),
                (int) (x + size), (int) (y + size / 4));
        g.drawLine((int) x, (int) (y + 3 * size / 4),
                (int) (x + size), (int) (y + 3 * size / 4));
        g.setColor(oldColor);
    }
}
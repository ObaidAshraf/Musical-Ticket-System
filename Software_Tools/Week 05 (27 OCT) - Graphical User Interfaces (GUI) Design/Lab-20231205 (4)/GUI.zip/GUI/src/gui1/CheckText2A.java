package gui1;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class CheckText2A extends JFrame implements ActionListener {

    JTextField myTxt = new JTextField(30);
    JCheckBox myRedChBx = new JCheckBox("click here for Red");
    JCheckBox myGreenChBx = new JCheckBox("click here for Green");

    public static void main(String[] args) {
        CheckText2A jf = new CheckText2A();
    }

    public CheckText2A() {
        setLayout(new FlowLayout());
        setSize(400, 120);
        setTitle("Red or Green?");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        add(myTxt);
        add(myRedChBx);
        add(myGreenChBx);
        myRedChBx.addActionListener(this);
        myGreenChBx.addActionListener(this);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (myRedChBx.isSelected()) {
            myTxt.setText("you have chosen Red");
        } else if (myGreenChBx.isSelected()) {
            myTxt.setText("you have chosen Green");
        }
    }
}

package gui1;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class LabelDemo2 extends JFrame implements ActionListener {

    public static void main(String[] args) {
        LabelDemo2 jf = new LabelDemo2();
    }

    public LabelDemo2() {
        setLayout(new FlowLayout());
        setSize(150, 300);
        setTitle("Labels");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        add(new Label("first label :"));
        add(new Label("second label :"));
        add(new Label("third label :"));
        add(new Label("fourth label :"));
        add(new Label("fifth label :"));
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        // add your event handling code here
    }
}

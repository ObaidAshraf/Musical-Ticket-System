package gui1;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class RadioText extends JFrame implements ActionListener {

    JTextField myTxt = new JTextField(30);
    JRadioButton myRedRB = new JRadioButton("click here for Red", true);
    JRadioButton myGreenRB = new JRadioButton("click here for Green", false);
    ButtonGroup colours = new ButtonGroup();

    public static void main(String[] args) {
        RadioText jf = new RadioText();
    }

    public RadioText() {
        setLayout(new FlowLayout());
        setSize(400, 120);
        setTitle("Red or Green?");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        colours.add(myRedRB);
        colours.add(myGreenRB);
        add(myTxt);
        add(myRedRB);
        add(myGreenRB);

        myRedRB.addActionListener(this);
        myGreenRB.addActionListener(this);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == myRedRB) {
            myTxt.setText("you have chosen Red");
        } else if (e.getSource() == myGreenRB) {
            myTxt.setText("you have chosen Green");
        }
    }
}

package gui1.puzzle;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Puzzle extends JFrame implements ActionListener {

    private Tile[][] tiles = new Tile[4][4];
    private int moves; // counter for number of moves made
    private int[] a = new int[16]; // for shuffling

    public static void main(String[] args) {
        Puzzle p = new Puzzle();
    }

    Puzzle() {
        setLayout(new GridLayout(4, 4));
        setSize(308, 327); // makes each tile 75 X 75 pixels
        setTitle("14-15 puzzle");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
        for (int i = 0; i < 4; ++i) {
            for (int j = 0; j < 4; ++j) {
                tiles[i][j] = new Tile();
                add(tiles[i][j]);
                tiles[i][j].setFont(new Font("Microsoft Sans Serif", Font.BOLD, 32));
                tiles[i][j].setFocusable(false); // improves appearance
                tiles[i][j].addActionListener(this);
            }
        }

        // Set the tile neighbours
        for (int i = 0; i < 4; ++i) {
            for (int j = 0; j < 4; ++j) {
                if (i > 0) {
                    tiles[i][j].setNorth(tiles[i - 1][j]);
                }
                if (i < 3) {
                    tiles[i][j].setSouth(tiles[i + 1][j]);
                }
                if (j > 0) {
                    tiles[i][j].setWest(tiles[i][j - 1]);
                }
                if (j < 3) {
                    tiles[i][j].setEast(tiles[i][j + 1]);
                }
            }
        }

        // Show solved state
        reset();
        display();
    }

    private void reset() {
        for (int i = 0; i < 16;) {
            a[i] = ++i; // solved state
        }
    }

    // Display the tiles except for the one with caption 16
    private void display() {
        for (int i = 0; i < 4; ++i) {
            for (int j = 0; j < 4; ++j) {
                tiles[i][j].setText("" + a[i * 4 + j]);
                tiles[i][j].setVisible(a[i * 4 + j] != 16);
            }
        }
    }

    // Shuffle the captions of the tiles in such
    // a way that the puzzle is always solvable.
    private void shuffle() {
        int s, t; // for swaps
        reset();
        // an even number of swaps guarantees a solution
        a[0] = 2;
        a[1] = 1; // one swap
        // fifteen more swaps
        for (int i = 0; i < 15; ++i) {
            // make sure t is random but not equal to i
            while ((t = (int) (Math.random() * 15)) == i);
            s = a[i];
            a[i] = a[t];
            a[t] = s;
        }
        // move blank square to a random column
        int k = (int) (Math.random() * 4);
        for (int i = 14; i > 14 - k; --i) {
            t = a[i];
            a[i] = a[i + 1];
            a[i + 1] = t;
        }
        // move blank square to a random row
        for (int m = (int) (Math.random() * 4), i = 11 - k; m > 0; i -= 4, --m) {
            t = a[i];
            a[i] = a[i + 4];
            a[i + 4] = t;
        }
        display();
        moves = 0;
    }

    // one way of checking for a solution
    private boolean solved() {
        for (int i = 0; i < 15; ++i) {
            if (Integer.parseInt(tiles[i / 4][i % 4].getText()) != (i + 1)) {
                return false;
            }
        }
        return true;
    }

    public void actionPerformed(ActionEvent e) {
        if (((Tile) e.getSource()).moved()) {
            moves++;
        }
        if (solved()) {
            if (moves > 1) {
                javax.swing.JOptionPane.showMessageDialog(this, "Solved in " + moves + " moves", "Game over", 1);
            }
            shuffle();
        }
    }
}
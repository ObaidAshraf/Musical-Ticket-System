package gui1;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class HelloWorldDone
        extends JFrame implements ActionListener {

    JTextField helloText = new JTextField(10);
    JButton helloButton = new JButton("Press Me");

    public static void main(String[] args) {
        HelloWorldDone jf = new HelloWorldDone();
    }

    public HelloWorldDone() {
        setLayout(new FlowLayout());
        setSize(200, 100);
        setTitle("Hello");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        add(helloText);
        add(helloButton);
        helloButton.addActionListener(this);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        helloText.setText("Hello World!");
    }
}

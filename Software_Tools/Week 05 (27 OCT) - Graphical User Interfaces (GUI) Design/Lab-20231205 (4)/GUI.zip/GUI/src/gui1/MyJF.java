package gui1;
 
 
 import java.awt.*;
 import javax.swing.*;
 import java.awt.event.*;
 
 public class MyJF extends JFrame
                   implements ActionListener
 {
 
     public static void main(String[] args)
     {
         MyJF jf = new MyJF();
     }
     
     public MyJF()
     {
         setLayout(new FlowLayout());
         setSize(400, 300);
         setTitle("Title");
         setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         setVisible(true);
     }
 
     public void actionPerformed(ActionEvent e)
     {
         // add your event handling code here
     }
 }

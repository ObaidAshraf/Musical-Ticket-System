package gui1;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class FirstFrame2 extends JFrame implements ActionListener {

    JButton myButton = new JButton("Press");

    public static void main(String[] args) {
        FirstFrame2 ff = new FirstFrame2();
    }

    public FirstFrame2() {
        setLayout(new FlowLayout());
        setSize(400, 400);
        setTitle("Button");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        add(myButton);
        myButton.addActionListener(this);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        setTitle("pressed");
    }
}

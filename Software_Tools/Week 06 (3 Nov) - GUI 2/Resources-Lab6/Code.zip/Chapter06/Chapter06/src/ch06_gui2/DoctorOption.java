package ch06_gui2;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class DoctorOption extends JFrame
        implements ActionListener {

    JTextField healthText = new JTextField(10);
    JRadioButton well = new JRadioButton("Well", true);
    JRadioButton ill = new JRadioButton("Unwell", false);
    ButtonGroup health = new ButtonGroup();
    Button send = new Button("Tell the doctor how you feel");

    public static void main(String[] args) {
        DoctorOption jf = new DoctorOption();
    }

    public DoctorOption() {
        setLayout(new FlowLayout());
        setSize(300, 100);
        setTitle("HeathCheck");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        add(healthText);
        health.add(well);
        health.add(ill);
        add(well);
        add(ill);
        add(send);
        send.addActionListener(this);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (well.isSelected()) {
            healthText.setText("In the pink");
            healthText.setBackground(Color.PINK);
        } else {
            healthText.setText("Looking a bit sick");
            healthText.setBackground(Color.GREEN);
        }
    }
}

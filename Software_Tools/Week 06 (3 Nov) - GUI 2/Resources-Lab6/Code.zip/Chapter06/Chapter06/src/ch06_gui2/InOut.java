package ch06_gui2;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class InOut extends JFrame
        implements ActionListener {

    JLabel nameLbl = new JLabel("Enter your first name:  ");
    JTextField nameTxt = new JTextField(10);
    JButton sub = new JButton("Submit details");
    JLabel messageLbl = new JLabel("A message for you:  ");
    JTextField messageTxt = new JTextField(10);

    public static void main(String[] args) {
        InOut jf = new InOut();
        jf.setVisible(true);
    }

    public InOut() {
        setLayout(new FlowLayout());
        setSize(200, 200);
        setTitle("IN & OUT");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        add(nameLbl);
        add(nameTxt);
        add(sub);
        add(messageLbl);
        add(messageTxt);
        sub.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e) {
        String name;
        name = nameTxt.getText();
        messageTxt.setText("Hi there  " + name);
    }
}

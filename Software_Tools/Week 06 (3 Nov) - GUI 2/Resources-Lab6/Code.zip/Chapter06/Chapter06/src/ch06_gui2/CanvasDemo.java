package ch06_gui2;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class CanvasDemo extends JFrame
        implements ActionListener {

    private MyCanvas canvas = new MyCanvas();

    public static void main(String[] args) {
        CanvasDemo jf = new CanvasDemo();
    }

    public CanvasDemo() {
        setLayout(new BorderLayout());
        setSize(400, 300);
        setTitle("Canvas demo");
        add("Center", canvas);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        // add your event handling code here
    }

    private class MyCanvas extends Canvas {

        @Override
        public void paint(Graphics g) {
            g.drawString("My first canvas program", 10, 20);
            g.drawOval(50, 50, 100, 25);
            g.drawRect(200, 50, 100, 25);
            g.setColor(Color.yellow);
            g.fillOval(50, 100, 70, 70);
            g.fillRect(200, 100, 90, 90);
            Image kate =
                    new ImageIcon("res/ch07_gui2/kate.jpg").getImage();
            Image don =
                    new ImageIcon("res/ch07_gui2/don.jpg").getImage();
            g.drawImage(kate, 330, 10, this);
            g.drawImage(don, 330, 190, this);
            g.setColor(Color.blue);
            g.setFont(new Font("Comic Sans MS", Font.BOLD, 30));
            g.drawString("That's all, folks", 10, 250);
        }
    }
}

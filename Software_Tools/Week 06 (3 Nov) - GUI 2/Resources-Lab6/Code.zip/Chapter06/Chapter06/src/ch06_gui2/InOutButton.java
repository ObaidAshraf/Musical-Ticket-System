package ch06_gui2;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class InOutButton extends JFrame
        implements ActionListener {

    JButton sub = new JButton("Press me!");
    JLabel messageLbl = new JLabel("A message for you:  ");
    JTextField messageTxt = new JTextField(10);

    public static void main(String[] args) {
        InOutButton jf = new InOutButton();
        jf.setVisible(true);
    }

    public InOutButton() {
        setLayout(new FlowLayout());
        setSize(200, 200);
        setTitle("InOut Button");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        add(sub);
        add(messageLbl);
        add(messageTxt);
        sub.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e) {
        messageTxt.setText("I'm imPRESSED");
    }
}

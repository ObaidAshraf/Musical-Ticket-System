package ch06_gui2;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Pool extends JFrame implements ActionListener, AdjustmentListener {

    private JScrollBar leftScr =
            new JScrollBar(JScrollBar.VERTICAL, 100, 0, 100, 300);
    private JScrollBar rightScr =
            new JScrollBar(JScrollBar.VERTICAL, 300, 0, 100, 300);
    private int left,  right; // depth of pool at each end in cm
    private JPanel bottom = new JPanel();
    private JButton reset = new JButton("RESET");
    private PoolCanvas poolCanvas = new PoolCanvas();

    public static void main(String[] args) {
        Pool pool = new Pool();
    }

    Pool() {
        setLayout(new BorderLayout());
        setTitle("Swimming pool calculator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setSize(344, 261); // so the canvas is 300 by 200
        leftScr.setBlockIncrement(5);
        rightScr.setBlockIncrement(5);
        leftScr.addAdjustmentListener(this);
        rightScr.addAdjustmentListener(this);
        reset.addActionListener(this);
        left = 100;
        right = 300;
        bottom.setLayout(new FlowLayout());
        bottom.add(reset);
        add("West", leftScr);
        add("East", rightScr);
        add("South", bottom);
        add("Center", poolCanvas);
        setResizable(false);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        left = 100;
        right = 300;
        leftScr.setValue(left);
        rightScr.setValue(right);
        poolCanvas.repaint();
    }

    public void adjustmentValueChanged(AdjustmentEvent e) {
        if (e.getSource() == leftScr) {
            left = leftScr.getValue();
        }
        if (e.getSource() == rightScr) {
            right = rightScr.getValue();
        }
        poolCanvas.repaint();
    }

    class PoolCanvas extends Canvas {

        @Override
        public void paint(Graphics g) {
            g.drawLine(50, 50, 250, 50);                          // top
            g.drawLine(250, 50, 250, 50 + right / 10);            // right
            g.drawLine(250, 50 + right / 10, 50, 50 + left / 10); // bottom
            g.drawLine(50, 50 + left / 10, 50, 50);               // left
            g.drawString("Left depth " + left + " cm", 50, 125);
            g.drawString("Right depth " + right + " cm", 50, 150);
            g.drawString("Volume " + ((left + right) * 0.5) +
                    " cubic metres", 50, 175);
        }
    }
}
package ch06_gui2;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Scribble extends JFrame {

    private ScribbleCanvas canvas = new ScribbleCanvas();

    public static void main(String[] args) {
        Scribble jf = new Scribble();
    }

    public Scribble() {
        setLayout(new BorderLayout());
        setSize(400, 300);
        setTitle("Scribble");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        add("Center", canvas);
        setVisible(true);
    }

    private class ScribbleCanvas extends Canvas
            implements MouseListener, MouseMotionListener {

        int lastX, lastY; // mouse position within canvas

        public ScribbleCanvas() {
            addMouseListener(this);
            addMouseMotionListener(this);
        }

        public void mousePressed(MouseEvent e) {
            lastX = e.getX();
            lastY = e.getY();
        }

        public void mouseDragged(MouseEvent e) {
            int x = e.getX(), y = e.getY();
            Graphics g = getGraphics();
            g.drawLine(lastX, lastY, x, y);
            lastX = x;
            lastY = y;
        }

        // additional event handlers required by the listeners
        public void mouseMoved(MouseEvent e) {
        }

        public void mouseClicked(MouseEvent e) {
        }

        public void mouseReleased(MouseEvent e) {
        }

        public void mouseEntered(MouseEvent e) {
        }

        public void mouseExited(MouseEvent e) {
        }
    }
}
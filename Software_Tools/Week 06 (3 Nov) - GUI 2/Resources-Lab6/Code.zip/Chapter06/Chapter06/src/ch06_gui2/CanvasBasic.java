package ch06_gui2;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class CanvasBasic
        extends JFrame implements ActionListener {

    private MyCanvas canvas = new MyCanvas();

    public static void main(String[] args) {
        CanvasBasic jf = new CanvasBasic();
    }

    public CanvasBasic() {
        setLayout(new BorderLayout());
        setSize(400, 300);
        setTitle("Title");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        // add your event handling code here
    }

    private class MyCanvas extends Canvas {

        public void paint(Graphics g) {
            // add your graphics code here
        }
    }
}

// This example is much more readable than Compact.java.

public class Readable
{
   public static void main(String[] args)
   {
      int shares = 220;
      double averagePrice = 14.67;

      System.out.println("There were " + shares 
                          + " shares sold at �"
                          + averagePrice + " per share.");
   }
}

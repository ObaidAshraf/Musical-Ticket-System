// A program for demonstrating boolean variables

public class TrueFalse
{
   public static void main(String[] args)
   {
      boolean bool;

      bool = true;
      System.out.println(bool);
      bool = false;
      System.out.println(bool);
   }
}

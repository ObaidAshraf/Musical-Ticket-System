import java.io.*;
import static java.lang.System.*;
import java.sql.*;
import org.apache.derby.drda.NetworkServerControl;

class DBHandler {

    private Statement myStatement;

    public DBHandler() {
        try {
            NetworkServerControl server = new NetworkServerControl();
            server.start(null);
            // Load JDBC driver
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
            //Establish a connection
            String sourceURL = "jdbc:derby://localhost:1527/"
                    + new File("UserDB").getAbsolutePath() + ";";
            Connection userDB = DriverManager.getConnection(sourceURL, "use", "use");
            myStatement = userDB.createStatement();
        } // The following exceptions must be caught
        catch (ClassNotFoundException cnfe) {
            out.println(cnfe);
        } catch (SQLException sqle) {
            out.println(sqle);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public boolean write(String f, String s, String id) {
        String writeString
                = "INSERT INTO Users(Firstname, Surname, Id) VALUES('"
                + f + "', '" + s + "', '" + id + "')";
        try {
            myStatement.executeUpdate(writeString);
        } catch (SQLException sqle) {
            return false; // duplicate key
        }
        return true; // inserted OK
    }

    public void displayUsers() {
        String output = "";
        Result windo = new Result();
        try {
            String queryString = "SELECT Firstname, Surname, Id FROM Users ORDER BY Id";
            ResultSet results = myStatement.executeQuery(queryString);
            while (results.next()) {
                output = output + (results.getString(1) + "  ");
                output = output + (results.getString(2) + "  ");
                output = output + (results.getString(3) + " \n");
            }
            windo.show.setText(output);
            results.close();
        } catch (SQLException sqle) {
            out.println(sqle);
        }
    }
}

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import static java.lang.System.*;
import java.sql.*;
import javax.swing.*;
import static javax.swing.JOptionPane.*;
import org.apache.derby.drda.NetworkServerControl;

public class DBDemo2 extends JFrame implements ActionListener {

    JTextField firstName, surname, loginId;
    JButton writeBtn, displayBtn;
    Connection userDB;
    Statement myStatement;

    public static void main(String[] args) {
        new DBDemo2();
    }

    public DBDemo2() {
        setLayout(new BorderLayout());
        firstName = new JTextField();
        surname = new JTextField();
        loginId = new JTextField();
        writeBtn = new JButton("Write to database");
        displayBtn = new JButton("Display database");
        JPanel middle = new JPanel();
        middle.setLayout(new GridLayout(6, 1, 5, 5));
        middle.add(new JLabel("First name:"));
        middle.add(firstName);
        middle.add(new JLabel("Surname:"));
        middle.add(surname);
        middle.add(new JLabel("Login ID:"));
        middle.add(loginId);
        add("Center", middle);
        JPanel bottom = new JPanel();
        bottom.add(writeBtn);
        bottom.add(displayBtn);
        add("South", bottom);
        add("West", new JPanel());
        add("East", new JPanel());
        writeBtn.addActionListener(this);
        displayBtn.addActionListener(this);
        setSize(300, 250);
        setTitle("Database demo 2");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        setResizable(false);
        try {
            NetworkServerControl server = new NetworkServerControl();
            server.start(null);
            // Load JDBC driver
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
            //Establish a connection
            String sourceURL = "jdbc:derby://localhost:1527/"
                    + new File("UserDB").getAbsolutePath() + ";";
            Connection userDB = DriverManager.getConnection(sourceURL, "use", "use");
            myStatement = userDB.createStatement();
        } // The following exceptions must be caught
        catch (ClassNotFoundException cnfe) {
            out.println(cnfe);
        } catch (SQLException sqle) {
            out.println(sqle);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == writeBtn) {
            String f = firstName.getText();
            String s = surname.getText();
            String id = loginId.getText();
            // if any field is blank, signal an error
            if (f.equals("") || s.equals("") || id.equals("")) {
                showMessageDialog(this, "One or more fields blank");
                return;
            }
            String writeString = "INSERT INTO Users(Firstname, Surname, Id) VALUES('"
                    + f + "', '" + s + "', '" + id + "')";
            try {
                myStatement.executeUpdate(writeString);
                firstName.setText("");
                surname.setText("");
            } catch (SQLException sqle) {
                showMessageDialog(this, "Duplicate key " + id);
            }
            loginId.setText("");
        }
        if (e.getSource() == displayBtn) {
            try {
                String queryString = "SELECT Firstname, Surname, Id FROM Users ORDER BY Id";
                ResultSet results = myStatement.executeQuery(queryString);
                while (results.next()) {
                    out.print(results.getString(1) + " ");
                    out.print(results.getString(2) + " ");
                    out.println(results.getString(3));
                }
                results.close();
            } catch (SQLException sqle) {
                out.println(sqle);
            }
        }
    }
}

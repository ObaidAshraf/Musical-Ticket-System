import java.io.File;
import java.sql.*;
import static javax.swing.JOptionPane.*;
import org.apache.derby.drda.NetworkServerControl;

public class DBDemo1 {

    public static void main(String[] args) {

        try {
            NetworkServerControl server = new NetworkServerControl();
            server.start(null);
            // Load JDBC driver
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
            //Establish a connection
            String sourceURL = "jdbc:derby://localhost:1527/"
                    + new File("UserDB").getAbsolutePath() + ";";
            Connection userDB = DriverManager.getConnection(sourceURL, "use", "use");
            //Create a statement
            Statement myStatement = userDB.createStatement();
            if (showConfirmDialog(null, "add Fred Bloggs to database?") == YES_OPTION) {
                String writeString = "INSERT INTO Users(Firstname, Surname, Id) VALUES('Fred', 'Bloggs', 'bf01')";
                myStatement.executeUpdate(writeString);
            }
            // Execute a statement
            ResultSet results = myStatement.executeQuery("SELECT Firstname, Surname, Id FROM Users ORDER BY Id");

            // Iterate through the result and print the names
            while (results.next()) {
                System.out.print(results.getString(1) + " ");
                System.out.print(results.getString(2) + " ");
                System.out.println(results.getString(3));
            }
            results.close();
            if (showConfirmDialog(null, "delete Fred Bloggs from database?") == YES_OPTION) {
                String deleteString = "DELETE FROM Users WHERE Surname='Bloggs' AND Firstname='Fred'";
                myStatement.executeUpdate(deleteString);
            } else {
                showMessageDialog(null, "OK - not deleted\n\ndo not add Fred Bloggs again\n"
                        + "or DBDemo1 will throw an SQL exception");
            }
            // Close the connection
            userDB.close();
        } // The following exceptions MUST be caught
        catch (SQLException sqle) {
            System.out.println(sqle);
        } catch (ClassNotFoundException cnfe) {
            System.out.println(cnfe);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}

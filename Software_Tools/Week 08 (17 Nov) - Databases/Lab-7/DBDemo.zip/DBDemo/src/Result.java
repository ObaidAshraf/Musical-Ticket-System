
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import static javax.swing.JOptionPane.*;

public class Result extends JFrame implements ActionListener {
    
    JTextArea show = new JTextArea(40, 20);
    
        public Result() {
        setLayout(new FlowLayout());
        setSize(300, 200);
        setTitle("Text Area Demo");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        add(show);
        show.setEditable(false);
        setVisible(true);
    }
    
    
    public void actionPerformed(ActionEvent e) {
        
    }
}
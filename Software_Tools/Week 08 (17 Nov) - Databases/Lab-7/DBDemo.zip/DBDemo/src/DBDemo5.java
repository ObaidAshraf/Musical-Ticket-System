import java.io.File;
import static java.lang.System.*;
import java.sql.*;
import static javax.swing.JOptionPane.*;
import org.apache.derby.drda.NetworkServerControl;

public class DBDemo5 {

    public static void main(String[] args) {
        try {
            NetworkServerControl server = new NetworkServerControl();
            server.start(null);
            // Load JDBC driver
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
            //Establish a connection
            String sourceURL = "jdbc:derby://localhost:1527/"
                    + new File("UserDB").getAbsolutePath() + ";";
            Connection userDB = DriverManager.getConnection(sourceURL, "use", "use");
            Statement myStatement = userDB.createStatement();
            if (showConfirmDialog(null, "add Fred Bloggs to database?") == YES_OPTION) {
                String writeString = "INSERT INTO Users(Firstname, Surname, Id) VALUES('Fred', 'Bloggs', 'bf01')";
                myStatement.executeUpdate(writeString);
            }
            ResultSet results = myStatement.executeQuery("SELECT Firstname, Surname, Id FROM Users ORDER BY Id");
            while (results.next()) {
                out.print(results.getString(1) + " ");
                out.print(results.getString(2) + " ");
                out.println(results.getString(3));
            }
            results.close();
            if (showConfirmDialog(null, "delete Fred Bloggs from database?") == YES_OPTION) {
                String deleteString = "DELETE FROM Users WHERE Surname='Bloggs' AND Firstname='Fred'";
                myStatement.executeUpdate(deleteString);
            } else {
                showMessageDialog(null, "OK - not deleted\n\ndo not add Fred Bloggs again\n"
                        + "or DBDemo1 will throw an SQL exception");
            }
            userDB.close();
        } // The following exceptions MUST be caught
        catch (ClassNotFoundException cnfe) {
            out.println(cnfe);
        } catch (SQLException sqle) {
            out.println(sqle);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}

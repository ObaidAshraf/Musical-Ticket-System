class Triangle {
    private double a, b, c;
    public Triangle(double aa, double bb, double cc) {
        a = aa; b = bb; c = cc;
    }
    public double area() {
        // check for impossible triangles and return NaN if found
        // all sides must be >= 0 and no side larger than the sum
        // of the other two
        if (a < 0) return Double.NaN;
        if (b < 0) return Double.NaN;
        if (c < 0) return Double.NaN;
        if (a + b < c) return Double.NaN;
        if (b + c < a) return Double.NaN;
        if (c + a < b) return Double.NaN;
        double s = (a+b+c)/2;
        return Math.sqrt(s * (s - a) * (s - b) * (s - c));
    }
}

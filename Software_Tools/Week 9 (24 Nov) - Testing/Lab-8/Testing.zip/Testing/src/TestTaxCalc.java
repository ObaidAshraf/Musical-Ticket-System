import static java.lang.System.out;
class TestTaxCalc {
    public static void main(String[] args) {
        TaxCalc t;

        // first test - single, no kids, gross 20000
        t = new TaxCalc(20000, 0, false);
        out.println("Test 1 - tax should be 3600: " + t.getTax());
        
        // second test - married, no kids, gross 20000
        t = new TaxCalc(20000, 0, true);
        out.println("Test 2 - tax should be 3400: " + t.getTax());     
        
        // third test - married, no kids, gross 23000 (borderline)
        t = new TaxCalc(23000, 0, true);
        out.println("Test 3 - tax should be 4000: " + t.getTax());     
        
        // fourth test - married, two kids, gross 24001 (borderline)
        t = new TaxCalc(24001, 2, true);
        out.println("Test 4 - tax should be 4000.40: " + t.getTax());     
        
        // fifth test - married, four kids, gross 35000
        t = new TaxCalc(35000, 4, true);
        out.println("Test 5 - tax should be 8000: " + t.getTax()); 
        
        // sixth test - single, no kids, gross 42000 (borderline)
        t = new TaxCalc(42000, 0, false);
        out.println("Test 6 - tax should be 12000: " + t.getTax()); 
        
        // seventh test - married, one kid, gross 43501 (borderline)
        t = new TaxCalc(43501, 1, true);
        out.println("Test 7 - tax should be 12000.60: " + t.getTax()); 
        
        // eighth test - single, two kids, gross 100000
        t = new TaxCalc(100000, 2, false);
        out.println("Test 8 - tax should be 46200: " + t.getTax()); 
        t = new TaxCalc(500, 14, true);
        out.println("Test 9 - tax should be 46200: " + t.getTax()); 
    }
}

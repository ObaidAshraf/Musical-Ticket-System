import static javax.swing.JOptionPane.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.text.DecimalFormat;

public class CarPark1 extends JFrame implements ActionListener {
    JButton tenP, twentyP, fiftyP, onePound, twoPounds, less1, oneTwo, twoThree, threeFour, overFour;
    JLabel messLabel = new JLabel("Amount to pay:  ");
    JTextField message = new JTextField(10);
    int amount = 0; // payment in pence
    DecimalFormat pounds = new DecimalFormat("£0.00");

    public static void main(String[] args) {
        CarPark1 c = new CarPark1();
        c.setTitle("Car park payment simulator");
        c.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c.setSize(500, 200);
        c.setVisible(true);
    }

    CarPark1() {
        setLayout(new BorderLayout());
        tenP = new JButton("10p"); tenP.addActionListener(this);
        twentyP = new JButton("20p"); twentyP.addActionListener(this);
        fiftyP = new JButton("50p"); fiftyP.addActionListener(this);
        onePound = new JButton("£1"); onePound.addActionListener(this);
        twoPounds = new JButton("£2"); twoPounds.addActionListener(this);
        less1 = new JButton("Up to 1 hr"); less1.addActionListener(this);
        oneTwo = new JButton("1 to 2 hr"); oneTwo.addActionListener(this);
        twoThree = new JButton("2 to 3 hr"); twoThree.addActionListener(this);
        threeFour = new JButton("3 to 4 hr"); threeFour.addActionListener(this);
        overFour = new JButton("Over 4 hr"); overFour.addActionListener(this);

        rightButtons();

        JPanel leftSide = new JPanel();
        leftSide.setLayout(new GridLayout(5, 1));
        leftSide.add(tenP);
        leftSide.add(twentyP);
        leftSide.add(fiftyP);
        leftSide.add(onePound);
        leftSide.add(twoPounds);
        add("West", leftSide);

        JPanel rightSide = new JPanel();
        rightSide.setLayout(new GridLayout(5, 1));
        rightSide.add(less1);
        rightSide.add(oneTwo);
        rightSide.add(twoThree);
        rightSide.add(threeFour);
        rightSide.add(overFour);
        add("East", rightSide);

        JPanel middle = new JPanel();
        middle.setLayout(new FlowLayout());
        middle.add(messLabel);
        message.setEditable(false);
        middle.add(message);
        add("Center", middle);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == less1) { amount = 100; leftButtons(); }
        if (e.getSource() == oneTwo) { amount = 200; leftButtons(); }
        if (e.getSource() == twoThree) { amount = 350; leftButtons(); }
        if (e.getSource() == threeFour) { amount = 500; leftButtons(); }
        if (e.getSource() == overFour) { amount = 600; leftButtons(); }
        if (e.getSource() == tenP) amount -= 10;
        if (e.getSource() == twentyP) amount -= 20;
        if (e.getSource() == fiftyP) amount -= 50;
        if (e.getSource() == onePound) amount -= 100;
        if (e.getSource() == twoPounds) amount -= 200;

        if (amount > 0) message.setText(pounds.format(amount / 100.0));
        else {
            message.setText("");
            if (amount < 0) {
                int change = -amount;
                showMessageDialog(this, "Your change is "
                    + pounds.format(change / 100.0)
                    + coins(change),
                    "Change", JOptionPane.INFORMATION_MESSAGE);
            } else {
                showMessageDialog(this, "Thank you",
                    "Exact amount", JOptionPane.INFORMATION_MESSAGE);
            }
            rightButtons();
        }
    }

    // enable left buttons, disable right buttons
    void leftButtons() {
        tenP.setEnabled(true);
        twentyP.setEnabled(true);
        fiftyP.setEnabled(true);
        onePound.setEnabled(true);
        twoPounds.setEnabled(true);
        less1.setEnabled(false);
        oneTwo.setEnabled(false);
        twoThree.setEnabled(false);
        threeFour.setEnabled(false);
        overFour.setEnabled(false);
    }

    // enable right buttons, disable left buttons
    void rightButtons() {
        tenP.setEnabled(false);
        twentyP.setEnabled(false);
        fiftyP.setEnabled(false);
        onePound.setEnabled(false);
        twoPounds.setEnabled(false);
        less1.setEnabled(true);
        oneTwo.setEnabled(true);
        twoThree.setEnabled(true);
        threeFour.setEnabled(true);
        overFour.setEnabled(true);
    }

    String coins(int change) {
        String answer = ":";
        if (change >= 100) {
            answer += "\nOne £1 coin";
            change -= 100;
        }
        if (change >= 50) {
            answer += "\nOne 50p coin";
            change -= 50;
        }
        if (change >= 40) {
            answer += "\nTwo 20p coins";
            change -= 40;
        }
        if (change >= 20) {
            answer += "\nOne 20p coin";
            change -= 20;
        }
        if (change >= 10) {
            answer += "\nOne 10p coin";
            change -= 10;
        }
        return answer;
    }
}

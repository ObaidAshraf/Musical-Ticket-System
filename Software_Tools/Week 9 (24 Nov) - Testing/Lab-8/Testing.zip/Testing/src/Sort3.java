class Sort3 {
    // Constructor takes 3 doubles and works out which is the
    // smallest, which the largest and which is the middle number
    // The get methods return these numbers

    private double small, medium, large;

    public Sort3(double a, double b, double c) {
        if (a < b && b < c) {
            small = a; medium = b; large = c;
        } else if (a < c && c < b) {
            small = a; medium = c; large = b;
        } else if (a < c) {
            small = b; medium = a; large = c;
        } else if (a < b) {
            small = c; medium = a; large = b;
        } else if (b < c) {
            small = b; medium = c; large = a;
        } else {
            small = c; medium = b; large = a;
        }
    }

    public double getSmall() { return small; }
    public double getMedium() { return medium; }
    public double getLarge() { return large; }

}

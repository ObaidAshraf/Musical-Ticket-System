class TestBiggest
{
    public static void main(String[] args) 
    {
        Biggest b;
        b = new Biggest(7, 4);
        System.out.println("Test 1: " + b.max());
    }
}

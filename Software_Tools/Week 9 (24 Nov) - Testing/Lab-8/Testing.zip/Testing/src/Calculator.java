import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Calculator extends JFrame implements ActionListener {
    JTextField input = new JTextField(10);
    JTextField result = new JTextField(12);
    JButton inv = new JButton("Invert");
    JButton sq = new JButton("Square Root");

    public static void main(String[] args) {
        new Calculator();
    }

    public Calculator() {
        setLayout(new FlowLayout());
        setSize(270, 100);
        setTitle("Calculator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        add(input);
        add(result); result.setEditable(false);
        add(inv); inv.addActionListener(this);
        add(sq); sq.addActionListener(this);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        int inp = Integer.parseInt(input.getText());
        if (e.getSource() == inv) {
            if (inp == 0) complain(); // can't invert 0
            else
                invertCalc(inp);
        }
        if (e.getSource() == sq) {
            if (inp < 0) complain(); // can't find sqrt of -ve number
            else
                sqrtCalc(inp);
        }
    }

    void invertCalc(int i) {
        result.setText("" + 1.0 / i); // "" + 1.0/i will convert 1.0/i to a string
    }

    void sqrtCalc(int i) {
        result.setText("" + Math.sqrt(i));
    }

    void complain() {
        result.setText("Error!");
    }
}

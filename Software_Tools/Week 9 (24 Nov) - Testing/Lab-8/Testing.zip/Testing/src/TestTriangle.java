class TestTriangle
{
    public static void main(String[] args) 
    {
        Triangle t;
        t = new Triangle(3, 4, 5);
        System.out.println("Test 1: " + t.area());
    }
}

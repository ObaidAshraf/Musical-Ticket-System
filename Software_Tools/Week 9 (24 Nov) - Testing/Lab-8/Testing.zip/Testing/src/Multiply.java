import javax.swing.*;

class  Multiply
{
	public static void main(String[] args) 
	{
		String inputStr = JOptionPane.showInputDialog("Input?");
		int input = Integer.parseInt(inputStr);
		if (input != 6)
			{
			int answer = input *2;
			System.out.println("the answer is  " + answer);
			}
		else  
		System.out.println("Have a nice day");
	}
}


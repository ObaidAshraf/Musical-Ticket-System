import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class V99OK extends JFrame implements ActionListener {
    JTextField number = new JTextField(2);
    JTextField vnumber = new JTextField(10);
    JButton verbalize = new JButton("Verbalize ->");
    static final String[] v19 =
        {"", "one", "two", "three", "four",
         "five", "six", "seven", "eight", "nine",
         "ten", "eleven", "twelve", "thirteen", "fourteen",
         "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"};
    static final String[] vty =
        {"", "", "twenty", "thirty", "forty", "fifty",
         "sixty", "seventy", "eighty", "ninety"};
    // so v19[5] is "five" and vty[4] is "forty", etc
    public static void main(String[] args) {
        new V99OK();
    }

    public V99OK() {
        setLayout(new FlowLayout());
        setSize(350, 75);
        setTitle("Verbalize a number");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        add(number);
        add(verbalize); verbalize.addActionListener(this);
        add(vnumber); vnumber.setEditable(false);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        int n; // number to be verbalized
        try {
            n = Integer.parseInt(number.getText());
        }
        catch (Exception ex) {
            number.setText("0");
            vnumber.setText("zero");
            return;
        }
        if (n < 0 || n > 99) vnumber.setText("Out of range");
        else vnumber.setText(verbalize(n));
    }

    String verbalize(int n) {
        // treat 0 as a special case
        if (n == 0) return "zero";
        else return v(n);
    }

    String v(int n) {
        if (n < 20) return v19[n];
        else {
            int tens = n / 10, units = n % 10;
            if (units == 0) return vty[tens];
            else return vty[tens] + " " + v19[units];
        }
    }
}

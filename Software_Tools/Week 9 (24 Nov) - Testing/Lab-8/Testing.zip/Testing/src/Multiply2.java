import javax.swing.*;

class  Multiply2
{
	public static void main(String[] args) 
	{
		String inputStr = JOptionPane.showInputDialog("Input?");
		double input = Double.parseDouble(inputStr);
		if (input != 6)
			{
			double answer = input *2;
			System.out.println("the answer is" + answer);
			}
		else 
		System.out.println("Have a nice day");
	}
}


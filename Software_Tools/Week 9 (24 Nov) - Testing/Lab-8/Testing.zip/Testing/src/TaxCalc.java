class TaxCalc {
    // instance variables
    private double gross;
    private int nKids;
    private boolean married;

    // constructor
    TaxCalc(double gross, int nKids, boolean married) {
        this.gross = gross;
        this.nKids = nKids;
        this.married = married;
    }

    // get method to return taxable
    public double getTaxable() {
        // calculate personal allowance using private methods
        double taxable = gross - personalAllowance() - childAllowance();
        return taxable;
    }

    // get method to return tax
    public double getTax() {
        double taxable, remainder, tax;
        taxable = getTaxable();
        if (taxable <= 20000) // first band
            tax = 0.2 * taxable;
        else if (taxable <= 40000) { // second band
            remainder = taxable - 20000;
            tax = 4000 + 0.4 * remainder;
        }
        else {
            remainder = taxable - 40000;
            tax = 4000 + 8000 + 0.6 * remainder;
        }
        return tax;
    }

    // private methods to help calculate the taxable income
    private double personalAllowance() {
        double pa;
        if (married) pa = 3000;
        else         pa = 2000;
        return pa;
    }

    private double childAllowance() {
        double ca = nKids * 500;
        return ca;
    }
}
import static java.lang.System.*;
class TestSort3 {
    public static void main(String[] args) {
        Sort3 s;
        s = new Sort3(1, 2, 3);
        out.println("Test 1: " + 
            s.getSmall() + " " + s.getMedium() + " " + s.getLarge());
        s = new Sort3(1, 3, 2);
        out.println("Test 2: " + 
            s.getSmall() + " " + s.getMedium() + " " + s.getLarge());
        s = new Sort3(2, 1, 3);
        out.println("Test 3: " + 
            s.getSmall() + " " + s.getMedium() + " " + s.getLarge());
        s = new Sort3(2, 3, 1);
        out.println("Test 4: " + 
            s.getSmall() + " " + s.getMedium() + " " + s.getLarge());
        s = new Sort3(3, 1, 2);
        out.println("Test 5: " + 
            s.getSmall() + " " + s.getMedium() + " " + s.getLarge());
        s = new Sort3(3, 2, 1);
        out.println("Test 6: " + 
            s.getSmall() + " " + s.getMedium() + " " + s.getLarge());
        s = new Sort3(1, 2, 2);
        out.println("Test 7: " + 
            s.getSmall() + " " + s.getMedium() + " " + s.getLarge());
        s = new Sort3(2, 1, 2);
        out.println("Test 8: " + 
            s.getSmall() + " " + s.getMedium() + " " + s.getLarge());
        s = new Sort3(2, 2, 1);
        out.println("Test 9: " + 
            s.getSmall() + " " + s.getMedium() + " " + s.getLarge());
        s = new Sort3(2, 1, 1);
        out.println("Test 10: " + 
            s.getSmall() + " " + s.getMedium() + " " + s.getLarge());
        s = new Sort3(1, 2, 1);
        out.println("Test 11: " + 
            s.getSmall() + " " + s.getMedium() + " " + s.getLarge());
        s = new Sort3(1, 1, 2);
        out.println("Test 12: " + 
            s.getSmall() + " " + s.getMedium() + " " + s.getLarge());
        s = new Sort3(1, 1, 1);
        out.println("Test 13: " + 
            s.getSmall() + " " + s.getMedium() + " " + s.getLarge());
    }
}

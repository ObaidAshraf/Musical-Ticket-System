class Biggest 
{
    private double a, b;
    public Biggest(double aa, double bb )
	{
        a = aa; b = bb; 
    }
    public double max() 
	{
        if (a >  b ) return a;
        else return b;
    }
}
